# Swift Sender 3.2.0

## Update
1. Back up the existing unpacked extension folder.
2. Extract this ZIP and copy its contents into that SAME folder. manifest.json must be directly in that folder.
3. At chrome://extensions, click Reload. Disable any other Swift Sender copies.
4. Refresh WhatsApp Web once. Stop any previous campaign before importing a new test.
5. Choose talha, import one correct test contact, and verify the result in WhatsApp and the report.

Using the same extension folder preserves the browser extension identity, activation, templates and reports. Removing the extension or using a new folder can lose access to the old storage.

## What changed
- Searches only in the New chat drawer. Ignores a covered background search input and clicks the actual contact-row button.
- Opens a unique saved-name result and verifies the phone in Contact info before entering the message. Ambiguous results pause.
- Compares Pakistani mobile variants 03xxxxxxxxx and 3xxxxxxxxx with +923xxxxxxxxx during recipient verification. Full original digits are still required.
- Reconnects the WhatsApp bridge, exposes current steps and errors, and pauses on uncertain outcomes.
- Persists every source row and campaign outcome. Stop does not delete the report. Duplicate callbacks cannot authorize a second click. Interrupted clicks are not automatically retried.
- Counts Sent only after seeing a NEW WhatsApp message ID with matching text and a checkmark. This does not mean the recipient read it. Missing confirmation is Unknown, not Sent.
- Adds the built-in talha template without overwriting an existing template of the same name. Template changes refresh imported messages before queueing.
- Keeps imported rows and filename while the popup is open and for approximately 45–50 seconds after closing; campaign reports persist independently.
- Preserves full numeric Excel values and expands scientific text exactly as requested. Expansion cannot restore rounded digits. Original source values remain in reports. Duplicate input rows remain duplicate recipients.
- Recognizes Consignee Phone and other supported phone headers, and retains rejected rows with their reasons.
- Includes a user-triggered read-only diagnostic export. Diagnostics never send messages.

## Limits
English WhatsApp Web is currently required. Selectors and Contact info layout can change between WhatsApp releases. Existing drafts, ambiguous contacts, missing confirmation and uncertain identity pause the campaign instead of guessing. Keep the tab open and do not manually change chats while the campaign operates.

An imported source value such as 3.24E+09 expands to 3240000000; it cannot reveal the original phone digits. Do not use rounded source data for real recipients. No country code is guessed during import.

Records live in Chrome local extension storage, not in a cloud backup. Export them periodically. Storage failure blocks click authorization. The diagnostic export excludes message text, contact names and phone-field values.

See VALIDATION.md for exactly what was tested. Simulated success is not a claim of successful live delivery on your account.
