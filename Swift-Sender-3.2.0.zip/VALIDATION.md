# Validation for 3.2.0

All checks listed here passed in the development environment.

- 19 Node regression tests covering CSV and Excel import, exact scientific expansion, source-row preservation, templating, persistence, pause/stop, stale protocols, wrong-tab results, duplicate results, reconnect failures, concurrent starts, click authorization, storage failure and restart/timeout handling.
- One regression test runs 30 independent mixed-outcome campaign simulations: 12 rows each, 360 source rows total. Each campaign retains all rows and authorizes at most one click per attempt despite duplicate callbacks.
- 15 simulated browser DOM flows covering labelled, focused and native search fields; already-open drawers; saved contacts; wrong contact numbers; a foreground drawer over a background search field; drawer row-button targeting; no results; ambiguous results; existing drafts; absent checkmarks; stale checkmarks; and cancelled click authorization.
- Four popup scenarios covering active/inactive activation views and draft restoration before/after expiry. These also verify the talha dropdown and template changes updating imported messages.
- Read-only diagnostic-export test verifies that fixture phone numbers, names and message text are absent from the report and collection requires an explicit request.
- JavaScript syntax and ZIP integrity checks.

The two-search-input and nested contact-row fixtures incorporate structural facts from the supplied diagnostic report. Real WhatsApp messages were NOT sent by the developer during these tests. Remaining live dependencies include the user's current WhatsApp DOM, login session, network, recipient number and the browser's delivery of input/click events.
