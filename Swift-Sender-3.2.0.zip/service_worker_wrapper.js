importScripts('analytics_engine.js', 'activation-legacy.js', 'background.js');

importScripts('diagnostics-worker.js');
