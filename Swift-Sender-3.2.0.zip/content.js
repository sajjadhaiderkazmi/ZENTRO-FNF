// In-page UI navigation only: never assign location or reload WhatsApp.
(()=>{
 if(globalThis.swiftSenderV320)return;globalThis.swiftSenderV320=true;
 chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(msg.action==='swift_ping'){reply({protocol:320,ready:!!document.querySelector('#pane-side,#main')});return false;}
 });
 let busy=false;
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const visible=e=>e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 const foreground=e=>{
  if(!visible(e))return false;
  const box=e.getBoundingClientRect();
  if(typeof document.elementFromPoint!=='function')return true;
  const x=Math.max(0,Math.min(innerWidth-1,box.left+box.width/2));
  const y=Math.max(0,Math.min(innerHeight-1,box.top+box.height/2));
  const hit=document.elementFromPoint(x,y);
  return !!hit&&(hit===e||e.contains(hit));
 };
 const norm=s=>String(s||'').replace(/\D/g,'');
 async function until(fn,ms=15000){const end=Date.now()+ms;while(Date.now()<end){const v=fn();if(v)return v;await wait(250);}throw Error('WhatsApp interface did not become ready');}
 const editableSelector='input:not([type]),input[type="text"],input[type="search"],textarea,[contenteditable="true"],[contenteditable="plaintext-only"]';
 const fieldText=e=>'value' in e?e.value:(e.innerText??e.textContent??'');
 const drawerMarkerSelector='[data-testid="new-chat-drawer-new-group-cell"],[data-testid="new-chat-drawer-new-contact-cell"],[data-testid="new-chat-drawer-new-community-cell"]';
 const searchScopes=new WeakMap();
 function drawerRoot(){
  const marker=[...document.querySelectorAll(drawerMarkerSelector)].find(visible);
  if(!marker)return null;
  const chatList=document.querySelector('#pane-side');
  for(let pane=marker.parentElement;pane&&pane!==document.body;pane=pane.parentElement){
   // Never walk out of the drawer into a wrapper containing the background chat list.
   if(chatList&&pane.contains(chatList)&&!chatList.contains(marker))return null;
   if([...pane.querySelectorAll(editableSelector)].some(foreground))return pane;
  }return null;
 }
 function findSearch(allowFocused=false,before=new Set()){
  const markerPresent=[...document.querySelectorAll(drawerMarkerSelector)].some(visible);
  const root=drawerRoot();
  if(markerPresent&&!root)return null;
  const candidates=[...(root||document).querySelectorAll(editableSelector)].filter(e=>foreground(e)&&!e.closest('#main')&&!e.disabled);
  const label=e=>['aria-label','placeholder','data-placeholder','title'].map(k=>e.getAttribute(k)||'').join(' ');
  const active=document.activeElement?.closest(editableSelector);
  let field=candidates.find(e=>e===active);
  field ||= candidates.find(e=>/search/i.test(label(e))&&/name|number|username/i.test(label(e)));
  if(!field&&allowFocused)field=candidates.find(e=>!before.has(e))||candidates.find(e=>/search/i.test(label(e)));
  if(field&&root)searchScopes.set(field,root);
  return field||null;
 }
 function input(e,text){
  e.focus();
  if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){
   const proto=e instanceof HTMLInputElement?HTMLInputElement.prototype:HTMLTextAreaElement.prototype;
   Object.getOwnPropertyDescriptor(proto,'value').set.call(e,text);
  }else{
   const range=document.createRange();range.selectNodeContents(e);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);
   if(!document.execCommand('insertText',false,text))e.textContent=text;
  }
  e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
 }

 // Compare Pakistani local mobile forms with the actual +92 number in Contact info.
 const canonicalPhone=value=>{const n=norm(value);return /^03\d{9}$/.test(n)?'92'+n.slice(1):/^3\d{9}$/.test(n)?'92'+n:n;};
 function resultRows(search){
  const drawer=searchScopes.get(search)||drawerRoot();
  function collect(panel){
   const listItems=[...panel.querySelectorAll('[role="listitem"],[role="row"]')].filter(visible);
   const items=listItems.length?listItems:[...panel.querySelectorAll('[data-testid="cell-frame-container"]')].filter(visible);
   const targets=items.map(e=>e.matches('[data-testid="cell-frame-container"]')?(e.closest('[role="button"]')||e):(e.querySelector('[role="button"]')||e));
   return [...new Set(targets)].filter(e=>!e.contains(search)&&!e.matches(drawerMarkerSelector)&&e.textContent.trim()&&!/^(New group|New contact|New community|New chat)$/i.test(e.textContent.trim()));
  }
  if(drawer)return collect(drawer);
  for(let panel=search.parentElement;panel&&panel!==document.body;panel=panel.parentElement){
   if(panel.querySelector('#main'))break;
   const rows=collect(panel);if(rows.length)return rows;
  }return [];
 }
 function contactInfo(){
  const heading=[...document.querySelectorAll('h1,h2,span,div')].find(e=>visible(e)&&e.textContent.trim()==='Contact info');
  if(!heading)return null;
  for(let pane=heading.parentElement;pane&&pane!==document.body;pane=pane.parentElement){
   if(pane.querySelector('#main,#pane-side'))break;
   const phones=[...pane.querySelectorAll('span,div,p,a')].filter(visible).map(e=>e.textContent.trim()).filter(t=>/^\+?[\d ()-]{7,25}$/.test(t));
   if(phones.length)return {pane,phones};
  }return null;
 }
 async function verifyRecipient(phone){
  const matches=value=>canonicalPhone(value)===canonicalPhone(phone);
  const header=await until(()=>document.querySelector('#main header'));
  if([...header.querySelectorAll('[title],span')].some(e=>matches(e.getAttribute('title')||e.textContent)))return;
  const name=header.querySelector('[title]');
  const open=[...header.querySelectorAll('button,[role="button"]')].find(e=>/contact info/i.test(e.getAttribute('aria-label')||e.getAttribute('title')||''))||name?.closest('[role="button"],button')||name;
  if(!open)throw Error('Cannot open Contact info to verify this saved contact');
  open.click();
  const info=await until(contactInfo);
  if(!info.phones.some(matches))throw Error('Contact info phone does not match the requested recipient; nothing sent');
  const close=[...info.pane.querySelectorAll('button,[role="button"]')].find(e=>/^(Close|Back)$/i.test(e.getAttribute('aria-label')||e.getAttribute('title')||'')||e.querySelector('[data-icon="x"],[data-icon="x-view"],[data-icon="back"]'));
  if(!close)throw Error('Number verified, but Contact info could not be closed. Close it and retry.');
  close.click();
 }

 async function execute(job){
  const reply=(status,reason)=>chrome.runtime.sendMessage({protocol:320,action:'swift_result',attemptId:job.attemptId,status,reason});
  let stage='Opening New chat';
  const progress=async text=>{stage=text;await chrome.runtime.sendMessage({protocol:320,action:'swift_stage',attemptId:job.attemptId,stage});};
  try{
   await progress(stage);
   const panelOpen=!!drawerRoot()||[...document.querySelectorAll('h1,h2,span,[role="heading"]')].some(e=>visible(e)&&e.textContent.trim()==='New chat');
   let search=panelOpen?findSearch(true):null;
   if(!search){
    const before=new Set(document.querySelectorAll(editableSelector));
    const newChat=[...document.querySelectorAll('button,[role="button"]')].find(e=>visible(e)&&(/^(new chat|new message)$/i.test(e.getAttribute('title')||e.getAttribute('aria-label')||'')||e.querySelector('[data-icon="new-chat-outline"],[data-icon="new-chat"]')));
    if(!newChat)throw Error('Cannot find New chat. Open New chat so its search field is visible.');
    newChat.click();
    await progress('Finding the New chat search field');
    search=await until(()=>findSearch(true,before));
   }
   await progress('Searching for '+job.phone);
   input(search,job.phone);
   await until(()=>search.isConnected&&fieldText(search).trim()===job.phone,3000);
   await progress('Waiting for search results for '+job.phone);
   // Allow the search result to settle; a name-only match still needs phone verification.
   await wait(800);
   const result=await until(()=>{
    if(fieldText(search).trim()!==job.phone)throw Error('Search changed while selecting the recipient');
    const rows=resultRows(search);
    const exact=rows.find(e=>[...e.querySelectorAll('[title],span')].some(n=>canonicalPhone(n.getAttribute('title')||n.textContent)===canonicalPhone(job.phone)));
    return exact||(rows.length===1?rows[0]:null);
   });
   await progress('Verifying the recipient phone number');
   result.click();
   await wait(600);
   await verifyRecipient(job.phone);
   const composer=await until(()=>{const e=document.querySelector('#main footer [contenteditable="true"][role="textbox"]');return visible(e)&&e;});
   // Allow the selected conversation to finish rendering before inserting text.
   await wait(700);
   if(composer.textContent.trim())throw Error('Chat contains an existing draft; clear it manually before retrying');
   await progress('Filling the message');
   input(composer,job.message);
   if(composer.innerText.replace(/\r/g,'').trim()!==job.message.replace(/\r/g,'').trim())throw Error('Composer text does not match the requested message');
   const messageId=e=>e.closest('[data-id]')?.getAttribute('data-id')||e.querySelector('[data-id]')?.getAttribute('data-id');
   const prior=new Set([...document.querySelectorAll('#main [data-id]')].map(e=>e.getAttribute('data-id')));
   const send=[...document.querySelectorAll('#main footer button,#main footer [role="button"]')].find(e=>visible(e)&&(e.querySelector('[data-icon="send"],[data-icon="wds-ic-send-filled"]')||e.getAttribute('aria-label')==='Send'));
   if(!send)throw Error('Send button unavailable');
   await progress('Waiting for WhatsApp send confirmation');
   const allowed=await chrome.runtime.sendMessage({protocol:320,action:'swift_before_click',attemptId:job.attemptId});
   if(!allowed?.ok)return;
   send.click();
   await until(()=>[...document.querySelectorAll('#main .message-out')].find(e=>messageId(e)&&!prior.has(messageId(e))&&e.querySelector('[data-icon="msg-check"],[data-icon="msg-dblcheck"]')&&[...e.querySelectorAll('.selectable-text')].some(n=>n.innerText.trim()===job.message.trim())),30000);
   await reply('sent','Observed a new matching outgoing message with a WhatsApp checkmark');
  }catch(e){await reply('unknown',stage+': '+e.message);}
 }
 setInterval(async()=>{
  if(busy)return;busy=true;
  try{const {job}=await chrome.runtime.sendMessage({protocol:320,action:'swift_poll'});if(job)await execute(job);}catch(e){console.warn('Swift Sender:',e.message);}finally{busy=false;}
 },1500);
})();
