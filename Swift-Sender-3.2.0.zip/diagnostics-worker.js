// Read-only diagnostics, explicitly invoked by the popup. No chat text or phone values.
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
 if(msg.action!=='swift_diagnostics'||sender.tab)return false;
 (async()=>{
  const {swiftLedger}=await chrome.storage.local.get('swiftLedger');
  const c=swiftLedger?.campaigns.find(c=>c.id===swiftLedger.active);
  const tabs=await chrome.tabs.query({url:'https://web.whatsapp.com/*'});
  const tab=tabs.find(t=>t.id===c?.tabId)||tabs.find(t=>t.active)||tabs[0];
  if(!tab)throw Error('Open the WhatsApp Web tab first');
  const [injected]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{
   const clean=v=>typeof v==='string'?v.replace(/\d{6,}/g,'[digits]').slice(0,240):v;
   const visible=e=>!!e?.getClientRects().length;
   const descriptor=e=>e?{tag:e.tagName,id:['main','pane-side','side'].includes(e.id)?e.id:(e.id?'[present]':''),className:typeof e.className==='string'?clean(e.className):'',role:e.getAttribute('role'),testId:clean(e.getAttribute('data-testid')),tabIndex:e.getAttribute('tabindex'),editable:e.getAttribute('contenteditable'),type:e.getAttribute('type'),hasTitle:e.hasAttribute('title'),labelKind:/search/i.test([e.getAttribute('aria-label'),e.getAttribute('placeholder'),e.getAttribute('data-placeholder'),e.getAttribute('title')].join(' '))?'search':null,icons:[...e.querySelectorAll('[data-icon]')].slice(0,5).map(n=>n.getAttribute('data-icon')),childCount:e.children.length}:null;
   const ancestors=e=>{const chain=[];for(let p=e;p&&chain.length<8;p=p.parentElement)chain.push(descriptor(p));return chain;};
   const editors=[...document.querySelectorAll('input,textarea,[contenteditable]')].filter(visible);
   const candidates=[...document.querySelectorAll('[role="listitem"],[role="row"],[role="button"],[data-testid="cell-frame-container"],span[title]')].filter(e=>visible(e)&&!e.closest('#main')).slice(0,80);
   return {readyState:document.readyState,hasMain:!!document.querySelector('#main'),hasChatList:!!document.querySelector('#pane-side'),focused:ancestors(document.activeElement),editors:editors.map(e=>({element:descriptor(e),isFocused:e===document.activeElement,hasValue:!!(e.value||e.textContent),ancestors:ancestors(e)})),candidates:candidates.map(e=>({element:descriptor(e),ancestors:ancestors(e)}))};
  }});
  let bridge;try{bridge=await chrome.tabs.sendMessage(tab.id,{action:'swift_ping'});}catch{bridge={error:'No content-script receiver'};}
  const row=c?.rows.find(r=>['opening','clicking'].includes(r.status));
  const last=c?.rows.filter(r=>r.status==='unknown').at(-1);
  // Do not export phone-bearing stage/error strings. Only structural state is needed.
  return {version:chrome.runtime.getManifest().version,capturedAt:new Date().toISOString(),campaign:{status:c?.status||'none',rowCount:c?.rows.length||0,activeRowStatus:row?.status||null,lastUnknown:!!last},bridge,dom:injected.result};
 })().then(data=>reply({data}),error=>reply({error:error.message}));return true;
});
