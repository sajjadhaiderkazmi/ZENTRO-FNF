document.addEventListener('DOMContentLoaded',()=>{
 const button=document.createElement('button');button.textContent='Download troubleshooting report';button.type='button';button.style.cssText='display:block;margin:12px auto;padding:10px;cursor:pointer';
 const note=document.createElement('p');note.style.cssText='font-size:12px;padding:0 15px';note.textContent='Read-only report of controls and extension state; no message text or contact numbers.';
 document.body.append(button,note);
 button.addEventListener('click',()=>{
  button.disabled=true;note.textContent='Reading WhatsApp controls…';
  chrome.runtime.sendMessage({action:'swift_diagnostics'},response=>{
   button.disabled=false;
   if(chrome.runtime.lastError||response?.error||!response?.data){note.textContent=response?.error||chrome.runtime.lastError?.message||'Could not read the WhatsApp tab.';return;}
   const url=URL.createObjectURL(new Blob([JSON.stringify(response.data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='swift-whatsapp-diagnostics.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
   note.textContent='Report downloaded. Attach swift-whatsapp-diagnostics.json in the support chat.';
  });
 });
});
