# Swift Sender 3.1.1 — test build

Extract this folder and load it through Chrome Extensions > Developer mode > Load unpacked. For an existing unpacked installation, back up its folder and replace its files in the same folder, then click Reload. This preserves the extension identity and its browser storage. Installing from another folder can create another extension identity; existing activation and records will not transfer automatically. Refresh WhatsApp Web once after updating to replace the old content script. Disable any other copy of Swift Sender.

Changes:
- No per-recipient tab navigation or page refresh. Uses New chat and searches the phone number inside WhatsApp.
- Each campaign and source row is saved before processing; stopping retains records. Worker restarts retain the current attempt. Uncertain attempts time out to Unknown and pause; they are never automatically resent.
- Success requires a new outgoing message with matching text and a WhatsApp checkmark. This is not proof the recipient read it.
- CSV imports preserve text numbers, first data rows and short rows. Supported headers include Phone, Mobile, Contact Number and WhatsApp Number. Headerless input supports one phone column or the original CN, COD, Name, Phone layout. Invalid rows remain visible in reports. No country code is guessed.
- Reports include every row with status and reason and export all campaigns to CSV. Legacy reports remain viewable; their historical inaccuracies cannot be reconstructed.

Use full international numbers, for example +923001234567. Local numbers such as 03001234567 are flagged for correction. Spreadsheet numbers already rounded by Excel cannot be recovered; format the source column as Text before exporting. Duplicate source rows are preserved and can therefore send twice; review the input first.

Live-test limitations:
- Automated regression tests passed; no messages were sent to real WhatsApp recipients during development.
- This build currently expects the English WhatsApp Web interface. It requires an exact phone-number match in both the search result and conversation header. Contacts displayed only by name may pause as Unknown. This intentionally avoids selecting or sending to an unverified chat.
- Interface changes may require selector adjustments. Unknown does not mean the number lacks a WhatsApp account. Check the recorded reason and chat manually before retrying.
- Pause prevents subsequent click authorization; a click already authorized may finish. Stop preserves such an outcome as Unknown if confirmation has not arrived.
- Activation behavior is retained. The legacy time-service domain is now declared in host permissions.
- Records live in Chrome local extension storage, not in a cloud backup. Export periodically. Uninstalling or clearing extension data removes them. Existing credentials and old reports are not migrated into a different extension identity.

Try two or three consenting test contacts first and compare the CSV rows with the report before using a larger list. Keep the WhatsApp tab open and avoid editing its chat while a campaign runs.

3.1.1 fixes a popup script loading-order error that left only the logo visible. Startup verified with both active and inactive activation states in a DOM harness. Live WhatsApp sending still requires user testing.
