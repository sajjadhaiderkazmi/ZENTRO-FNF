async function handleFile(event) {
 const file=event.target.files[0];updateFileNameDisplay(file);if(!file)return;
 try {
  const csv=/\.csv$/i.test(file.name);
  const book=XLSX.read(csv?await file.text():await file.arrayBuffer(),{type:csv?'string':'array',raw:true,cellText:true});
  const rows=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1,raw:false,defval:'',blankrows:true});
  processData(rows);
 }catch(error){parsedData=[];document.getElementById('start-btn').disabled=true;updateStatus('Import failed: '+error.message,true);}
}
function processData(rows) {
 parsedData=SwiftImport.rows(rows,templateInput.value);
 renderPreview();const invalid=parsedData.filter(r=>r.importError).length;
 document.getElementById('start-btn').disabled=!parsedData.some(r=>!r.importError);
 document.getElementById('preview-count').textContent=`${parsedData.length} source rows; ${invalid} need correction (retained in reports).`;
 updateStatus(`Imported ${parsedData.length} rows. ${invalid} invalid rows will be recorded, not sent. Use country codes.`,invalid>0);
 chrome.storage.local.set({swiftImportDraft:parsedData});
}
