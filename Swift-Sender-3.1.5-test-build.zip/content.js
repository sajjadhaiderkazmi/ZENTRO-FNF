// In-page UI navigation only: never assign location or reload WhatsApp.
(()=>{
 if(globalThis.swiftSenderV315)return;globalThis.swiftSenderV315=true;
 chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(msg.action==='swift_ping'){reply({protocol:315,ready:!!document.querySelector('#pane-side,#main')});return false;}
 });
 let busy=false;
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const visible=e=>e&&e.getClientRects().length>0;
 const norm=s=>String(s||'').replace(/\D/g,'');
 async function until(fn,ms=15000){const end=Date.now()+ms;while(Date.now()<end){const v=fn();if(v)return v;await wait(250);}throw Error('WhatsApp interface did not become ready');}
 function input(e,text){e.focus();document.execCommand('selectAll',false,null);document.execCommand('insertText',false,text);e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));}
 async function execute(job){
  const reply=(status,reason)=>chrome.runtime.sendMessage({protocol:315,action:'swift_result',attemptId:job.attemptId,status,reason});
  let stage='Opening New chat';
  const progress=async text=>{stage=text;await chrome.runtime.sendMessage({protocol:315,action:'swift_stage',attemptId:job.attemptId,stage});};
  try{
   await progress(stage);
   const newChat=[...document.querySelectorAll('button,[role="button"]')].find(e=>visible(e)&&(/^(new chat|new message)$/i.test(e.getAttribute('title')||e.getAttribute('aria-label')||'')||e.querySelector('[data-icon="new-chat-outline"],[data-icon="new-chat"]')));
   if(!newChat)throw Error('Cannot find New chat. English WhatsApp Web UI is currently required.');
   newChat.click();
   const search=await until(()=>[...document.querySelectorAll('[contenteditable="true"][role="textbox"]')].find(e=>visible(e)&&!e.closest('#main')&&/search/i.test([e.getAttribute('aria-label'),e.getAttribute('data-placeholder'),e.parentElement?.textContent].join(' '))));
   await progress('Searching for '+job.phone);
   input(search,job.phone);
   // Exact number match only. Never choose an arbitrary first search result.
   const result=await until(()=>[...document.querySelectorAll('[role="listitem"], [role="row"]')].find(e=>visible(e)&&!e.closest('#main')&&[...e.querySelectorAll('[title],span')].some(n=>norm(n.getAttribute('title')||n.textContent)===norm(job.phone))));
   await progress('Verifying the recipient phone number');
   result.click();
   await until(()=>[...document.querySelectorAll('#main header [title],#main header span')].some(e=>norm(e.getAttribute('title')||e.textContent)===norm(job.phone)));
   const composer=await until(()=>{const e=document.querySelector('#main footer [contenteditable="true"][role="textbox"]');return visible(e)&&e;});
   // Allow the selected conversation to finish rendering before inserting text.
   await wait(700);
   if(composer.textContent.trim())throw Error('Chat contains an existing draft; clear it manually before retrying');
   await progress('Filling the message');
   input(composer,job.message);
   if(composer.innerText.replace(/\r/g,'').trim()!==job.message.replace(/\r/g,'').trim())throw Error('Composer text does not match the requested message');
   const prior=new Set([...document.querySelectorAll('#main .message-out')].map(e=>e.getAttribute('data-id')||e));
   const send=[...document.querySelectorAll('#main footer button,#main footer [role="button"]')].find(e=>visible(e)&&(e.querySelector('[data-icon="send"],[data-icon="wds-ic-send-filled"]')||e.getAttribute('aria-label')==='Send'));
   if(!send)throw Error('Send button unavailable');
   const allowed=await chrome.runtime.sendMessage({protocol:315,action:'swift_before_click',attemptId:job.attemptId});
   if(!allowed?.ok)return;
   await progress('Waiting for WhatsApp send confirmation');
   send.click();
   await until(()=>[...document.querySelectorAll('#main .message-out')].find(e=>!prior.has(e.getAttribute('data-id')||e)&&e.querySelector('[data-icon="msg-check"],[data-icon="msg-dblcheck"]')&&[...e.querySelectorAll('.selectable-text')].some(n=>n.innerText.trim()===job.message.trim())),30000);
   await reply('sent','Observed a new matching outgoing message with a WhatsApp checkmark');
  }catch(e){await reply('unknown',stage+': '+e.message);}
 }
 setInterval(async()=>{
  if(busy)return;busy=true;
  try{const {job}=await chrome.runtime.sendMessage({protocol:315,action:'swift_poll'});if(job)await execute(job);}catch(e){console.warn('Swift Sender:',e.message);}finally{busy=false;}
 },1500);
})();
