// Durable campaign coordinator. Only this worker writes the campaign ledger.
let serial=Promise.resolve();
const run=fn=>{const p=serial.then(fn);serial=p.catch(console.error);return p;};
const load=async()=> (await chrome.storage.local.get('swiftLedger')).swiftLedger||{campaigns:[],active:null};
const current=s=>s.campaigns.find(c=>c.id===s.active);
const terminal=r=>!['pending','opening','clicking'].includes(r.status);
async function save(s){
 const c=current(s),rows=c?.rows||[];
 await chrome.storage.local.set({swiftLedger:s,isSending:!!c&&['running','paused'].includes(c.status),isPaused:c?.status==='paused',messageQueue:rows,currentIndex:rows.filter(terminal).length,failedNumbers:rows.filter(r=>r.status==='invalid').map(r=>r.phone)});
}
async function next(s){
 const c=current(s);if(!c||c.status!=='running')return;
 let job=c.rows.find(r=>['opening','clicking'].includes(r.status));
 if(job){if(Date.now()-job.startedAt>90000){job.status='unknown';job.reason='No confirmation before timeout; check chat before retrying';c.status='paused';await save(s);}return;}
 if(Date.now()<(c.nextAt||0))return;
 job=c.rows.find(r=>r.status==='pending');
 if(!job){c.status='completed';await save(s);return;}
 job.status='opening';job.attemptId=crypto.randomUUID();job.startedAt=Date.now();await save(s);
}
chrome.alarms.create('swift-check',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='swift-check')run(async()=>{const s=await load();await next(s);});});
const actions=new Set(['start_sending','get_status','pause_sending','resume_sending','stop_sending','swift_poll','swift_before_click','swift_result','swift_stage']);
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
 if(!actions.has(msg.action))return false;
 run(async()=>{
  const s=await load();let c=current(s);
  if(msg.action.startsWith('swift_')){
   if(msg.protocol!==315)return {cancelled:true};
   if(!c||sender.tab?.id!==c.tabId||!sender.url?.startsWith('https://web.whatsapp.com/'))return {cancelled:true};
   if(msg.action==='swift_poll'){
    await next(s);const row=c.rows.find(r=>r.status==='opening');
    return c.status==='running'&&row?{job:row}:{};
   }
   const r=c.rows.find(r=>r.attemptId===msg.attemptId);
   if(!r||terminal(r))return {cancelled:true};
   if(msg.action==='swift_stage'){r.stage=String(msg.stage||'');await save(s);return {ok:true};}
   if(msg.action==='swift_before_click'){
    if(c.status!=='running'||r.status!=='opening')return {cancelled:true};
    r.status='clicking';await save(s);return {ok:true};
   }
   if(!['sent','invalid','unknown'].includes(msg.status))throw Error('Invalid outcome');
   r.status=msg.status;r.reason=String(msg.reason||'');r.finishedAt=Date.now();
   if(r.status==='unknown'&&c.status==='running')c.status='paused';
   c.nextAt=Date.now()+c.delayMs;await save(s);await next(s);return {ok:true};
  }
  // Control commands must originate in the extension UI.
  if(sender.tab)return {error:'Use the extension popup'};
  if(msg.action==='start_sending'){
   if(c&&['running','paused'].includes(c.status))throw Error('Stop or finish the current campaign first');
   if(!(await verifyActivationState()).isActive)throw Error('Activation expired or invalid');
   if(!Array.isArray(msg.data)||!msg.data.length)throw Error('Import contacts first');
   const tabs=await chrome.tabs.query({url:'https://web.whatsapp.com/*'});
   const tab=tabs.find(t=>t.active)||tabs[0];if(!tab)throw Error('Open WhatsApp Web and sign in first');
   await connectTab(tab.id);
   await chrome.tabs.update(tab.id,{active:true});
   const rows=msg.data.map((r,i)=>({...r,id:crypto.randomUUID(),sourceRow:r.sourceRow||i+1,status:r.importError?'invalid':'pending',reason:r.importError||''}));
   c={id:crypto.randomUUID(),date:new Date().toISOString(),tabId:tab.id,status:'running',delayMs:Math.max(3,Number(msg.delayMin)||3,Number(msg.delayMax)||5)*1000,rows};s.campaigns.unshift(c);s.active=c.id;await save(s);await next(s);return {status:'started'};
  }
  if(msg.action==='get_status'){await next(s);const row=c?.rows.find(r=>['opening','clicking'].includes(r.status));const last=c?.rows.filter(r=>r.status==='unknown').at(-1);return {stage:row?.stage||'Connecting to WhatsApp',reason:c?.status==='paused'?last?.reason||'Paused by you':'',campaignStatus:c?.status||'idle',isSending:!!c&&['running','paused'].includes(c.status),isPaused:c?.status==='paused',currentIndex:c?.rows.filter(terminal).length||0,totalCount:c?.rows.length||0};}
  if(!c)return {status:'idle'};
  if(msg.action==='pause_sending')c.status='paused';
  if(msg.action==='resume_sending'){await connectTab(c.tabId);c.status='running';}
  if(msg.action==='stop_sending'){
   c.status='stopped';for(const r of c.rows){if(r.status==='pending'||r.status==='opening')r.status='cancelled';else if(r.status==='clicking'){r.status='unknown';r.reason='Stopped after click authorization; verify manually';}}
  }
  await save(s);await next(s);return {status:c.status};
 }).then(reply,error=>reply({error:error.message}));return true;
});

async function connectTab(tabId){
 let ready;
 try{ready=await chrome.tabs.sendMessage(tabId,{action:'swift_ping'});}catch{}
 if(ready?.protocol!==315){
  try{await chrome.scripting.executeScript({target:{tabId},files:['content.js']});ready=await chrome.tabs.sendMessage(tabId,{action:'swift_ping'});}
  catch{throw Error('Cannot connect to WhatsApp. Refresh the WhatsApp tab once, sign in, then start again.');}
 }
 if(!ready?.ready)throw Error('WhatsApp is not ready. Sign in and wait for the chat list to load.');
}
