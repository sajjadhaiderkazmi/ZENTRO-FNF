let campaigns=[];
const cell=(parent,text,tag='td')=>{const e=document.createElement(tag);e.textContent=String(text??'');parent.append(e);return e;};
async function render(){
 const data=await chrome.storage.local.get(['swiftLedger','reportsHistory']);campaigns=data.swiftLedger?.campaigns||[];
 const root=document.getElementById('records');root.replaceChildren();
 for(const c of campaigns){
  cell(root,`${c.date} — ${c.status}`,'h2');
  const counts={};for(const r of c.rows)counts[r.status]=(counts[r.status]||0)+1;
  cell(root,`${c.rows.length} rows — `+Object.entries(counts).map(([k,v])=>`${k}: ${v}`).join(', '),'p');
  const table=document.createElement('table');root.append(table);const head=document.createElement('tr');table.append(head);
  for(const s of ['CSV row','Original number','Phone','Status','Reason'])cell(head,s,'th');
  for(const r of c.rows){const tr=document.createElement('tr');table.append(tr);for(const v of [r.sourceRow,r.rawPhone,r.phone,r.status,r.reason])cell(tr,v);}
 }
 const legacy=document.getElementById('legacy');legacy.replaceChildren();
 for(const r of data.reportsHistory||[])cell(legacy,`${r.date}: ${r.totalCount} total, ${r.successCount} reported successful, ${r.failedCount} reported failed (legacy totals were not independently verified).`,'p');
}
function csvCell(v){let s=String(v??'');if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
document.getElementById('export').onclick=()=>{
 const rows=[['Campaign','Date','Source row','Original phone','Phone','Message','Status','Reason','Confirmed at']];
 for(const c of campaigns)for(const r of c.rows)rows.push([c.id,c.date,r.sourceRow,r.rawPhone,r.phone,r.message,r.status,r.reason,r.finishedAt?new Date(r.finishedAt).toISOString():'']);
 const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
 const a=document.createElement('a');a.href=url;a.download='swift-sender-records.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.swiftLedger)render();});render();
