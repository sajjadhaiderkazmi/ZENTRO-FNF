/* Text-only phone parsing: never convert identifiers to JavaScript numbers. */
globalThis.SwiftImport = {
 normalize(value) {
  let s=String(value??'').trim().replace(/^'/,'');
  let warning='';
  if (/e/i.test(s)) {
   const match=s.match(/^\+?(\d+)(?:\.(\d+))?[eE]([+-]?\d+)$/);
   if(!match)return {error:'Invalid scientific notation'};
   const exponent=Number(match[3]);
   if(!Number.isSafeInteger(exponent)||Math.abs(exponent)>30)return {error:'Scientific exponent is outside the phone-number range'};
   const digits=match[1]+(match[2]||'');const point=match[1].length+exponent;
   if(point<=0||point<digits.length&&/[1-9]/.test(digits.slice(point)))return {error:'Phone number must be a whole number'};
   s=(point<digits.length?digits.slice(0,point):digits+'0'.repeat(point-digits.length)).replace(/^0+(?=\d)/,'');
   warning='Expanded scientific notation; verify the digits and country code. Rounding in the source cannot be reversed.';
  }
  if (!/^\+?[\d\s().-]+$/.test(s)) return {error:'Missing or invalid phone'};
  s=s.replace(/[\s().-]/g,'').replace(/^\+/,'').replace(/^00/,'');
  if (!/^[1-9]\d{6,14}$/.test(s)) return {error:'Use international format with country code (no local leading zero)'};
  return {phone:s,warning};
 },
 rows(data,template) {
  const aliases={phone:['phone','phone number','mobile','mobile number','contact','contact number','consignee phone','consignee phone number','customer phone','customer phone number','whatsapp','whatsapp number'],name:['name','consignee','consignee name','customer'],cn:['cn','cn number','tracking','consignment'],cod:['cod','cod amount','amount','price']};
  const first=data.findIndex(r=>r.some(v=>String(v??'').trim()));if(first<0)return [];
  const headers=data[first].map(v=>String(v??'').replace(/^\uFEFF/,'').trim().toLowerCase());
  let col={};for(const [k,names] of Object.entries(aliases))col[k]=headers.findIndex(h=>names.includes(h));
  const header=col.phone>=0;
  if(!header)col=data[first].length===1?{phone:0,name:-1,cn:-1,cod:-1}:{phone:3,cn:0,cod:1,name:2};
  const out=[];
  for(let i=first+(header?1:0);i<data.length;i++){
   const r=data[i];if(!r.some(v=>String(v??'').trim()))continue;
   const raw=String(r[col.phone]??'');const n=typeof r[col.phone]==='number'&&!Number.isSafeInteger(r[col.phone])?{error:'Excel phone must be a whole, precisely stored number; use Text format'}:this.normalize(raw);
   const values={'Consignee Name':r[col.name]??'','CN Number':r[col.cn]??'','COD Amount':r[col.cod]??''};
   const message=template.replace(/\{(Consignee Name|CN Number|COD Amount)\}/gi,(_,key)=>String(values[Object.keys(values).find(k=>k.toLowerCase()===key.toLowerCase())]));
   out.push({sourceRow:i+1,rawPhone:raw,phone:n.phone||raw,message,importWarning:n.warning||'',importError:n.error||(!message.trim()?'Empty message':'')});
  }return out;
 }
};
if(typeof module!=='undefined')module.exports=SwiftImport;
