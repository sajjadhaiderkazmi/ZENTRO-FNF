const a0_0x2b6732 = a0_0x3e05;
function a0_0x3e05(_0x225afd, _0x154f83) {
    _0x225afd = _0x225afd - 480;
    const _0x2f5b09 = a0_0x2f5b();
    let _0x3e05a0 = _0x2f5b09[_0x225afd];
    if (a0_0x3e05['BERtUk'] === undefined) {
        var _0x59c770 = function (_0x3470be) {
            const _0x3cbf11 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
            let _0x180fb1 = '', _0x1fa735 = '';
            for (let _0x3adcd0 = 0, _0x175a6f, _0x5dde13, _0x420a42 = 0; _0x5dde13 = _0x3470be['charAt'](_0x420a42++); ~_0x5dde13 && (_0x175a6f = _0x3adcd0 % 4 ? _0x175a6f * 64 + _0x5dde13 : _0x5dde13, _0x3adcd0++ % 4) ? _0x180fb1 += String['fromCharCode'](255 & _0x175a6f >> (-2 * _0x3adcd0 & 6)) : 0) {
                _0x5dde13 = _0x3cbf11['indexOf'](_0x5dde13);
            }
            for (let _0x217973 = 0, _0x5da487 = _0x180fb1['length']; _0x217973 < _0x5da487; _0x217973++) {
                _0x1fa735 += '%' + ('00' + _0x180fb1['charCodeAt'](_0x217973)['toString'](16))['slice'](-2);
            }
            return decodeURIComponent(_0x1fa735);
        };
        a0_0x3e05['ZFmrng'] = _0x59c770, a0_0x3e05['enNfpH'] = {}, a0_0x3e05['BERtUk'] = !![];
    }
    const _0x10bb53 = _0x2f5b09[0];
    a0_0x3e05['uNIJVk'] !== _0x10bb53 && (a0_0x3e05['enNfpH'] = {}, a0_0x3e05['uNIJVk'] = _0x10bb53);
    const _0x3e816f = a0_0x3e05['enNfpH'][_0x225afd];
    return _0x3e816f === undefined ? (_0x3e05a0 = a0_0x3e05['ZFmrng'](_0x3e05a0), a0_0x3e05['enNfpH'][_0x225afd] = _0x3e05a0) : _0x3e05a0 = _0x3e816f, _0x3e05a0;
}
(function (_0x39b19c, _0x589ea2) {
    const _0x429490 = a0_0x3e05, _0x35e437 = _0x39b19c();
    while (!![]) {
        try {
            const _0x3cf315 = parseInt('765805SExnIb') / 1 + -parseInt('1108138WvebDu') / 2 * (parseInt('6qaSrQZ') / 3) + parseInt('6508636ThebRv') / 4 + parseInt('7617750oDGSuY') / 5 + -parseInt('1506900EwxFud') / 6 * (-parseInt('28CdqOLA') / 7) + -parseInt('24NAjtvs') / 8 * (parseInt('4170258ZHMPNL') / 9) + -parseInt('15994770McNolT') / 10;
            if (_0x3cf315 === _0x589ea2)
                break;
            else
                _0x35e437['push'](_0x35e437['shift']());
        } catch (_0x1b89c8) {
            _0x35e437['push'](_0x35e437['shift']());
        }
    }
}(a0_0x2f5b, 823413));
let messageQueue = [], currentIndex = 0, isSending = ![], isPaused = ![], failedNumbers = [], targetTabId = null, currentTimeoutId = null, delayMin = 3, delayMax = 5;
async function fetchTrueTime() {
    const _0x1c027c = a0_0x3e05, _0x2c3d70 = {
            'TyPKB': function (_0x28c311) {
                return _0x28c311();
            },
            'yketr': function (_0x23c63a, _0x2ae265) {
                return _0x23c63a - _0x2ae265;
            },
            'ccqgb': function (_0x137095, _0x3757c3) {
                return _0x137095 > _0x3757c3;
            },
            'CaIdU': 'reportsHistory',
            'zJOjs': function (_0x407ab2, _0x5a408c) {
                return _0x407ab2 === _0x5a408c;
            },
            'MqPpM': 'JJqpn',
            'aOTDq': 'xPYsn',
            'twBko': 'Time API failed',
            'KrGcd': 'HDwLt',
            'UrkXf': 'Failed to fetch world time:'
        };
    try {
        if (_0x2c3d70['zJOjs'](_0x2c3d70['MqPpM'], _0x2c3d70['aOTDq']))
            _0xb31ce = _0x34a62f[0]['id'], _0x5ab66c['tabs']['update'](_0x5c2278, { 'active': !![] }), _0x2c3d70['TyPKB'](_0x4b7dd2);
        else {
            const _0x28fcf8 = await fetch('https://worldtimeapi.org/api/timezone/Etc/UTC');
            if (!_0x28fcf8['ok'])
                throw new Error(_0x2c3d70['twBko']);
            const _0x4c3dca = await _0x28fcf8['json']();
            return new Date(_0x4c3dca['datetime'])['getTime']();
        }
    } catch (_0x20b395) {
        if (_0x2c3d70['KrGcd'] !== _0x2c3d70['KrGcd'])
            _0x52b1d2['storage']['local']['get']([_0x2c3d70['CaIdU']], _0x43ede8 => {
                const _0x598a4b = _0x1c027c, _0x2d56d6 = _0x43ede8['reportsHistory'] || [], _0x3a06ba = {
                        'id': _0x50716f['now'](),
                        'date': new _0x41d4a8()['toLocaleString'](),
                        'totalCount': _0x334df3['length'],
                        'successCount': _0x2c3d70['yketr'](_0x175292['length'], _0x9b3a24['length']),
                        'failedCount': _0x175988['length'],
                        'failedNumbers': [..._0x5975c9]
                    };
                _0x2d56d6['unshift'](_0x3a06ba), _0x2c3d70['ccqgb'](_0x2d56d6['length'], 10) && (_0x2d56d6['length'] = 10), _0x541d4e['storage']['local']['set']({ 'reportsHistory': _0x2d56d6 });
            });
        else
            return console['error'](_0x2c3d70['UrkXf'], _0x20b395), Date['now']();
    }
}
async function verifyActivationState() {
    const _0xeda0f8 = a0_0x3e05, _0x5ba31a = {
            'NtWcv': function (_0x54e877, _0x1fa56c) {
                return _0x54e877(_0x1fa56c);
            },
            'RHhyA': function (_0x32a195) {
                return _0x32a195();
            },
            'UQTaA': function (_0x3d5c7a, _0x51c362) {
                return _0x3d5c7a - _0x51c362;
            },
            'tzfmX': function (_0x42f01f, _0x4c9b9a) {
                return _0x42f01f * _0x4c9b9a;
            },
            'lpZnR': function (_0x22db88, _0x460796) {
                return _0x22db88 * _0x460796;
            },
            'flzQz': function (_0x53c312, _0x303d6a) {
                return _0x53c312 >= _0x303d6a;
            },
            'MvZej': function (_0x432a94, _0x43068d) {
                return _0x432a94(_0x43068d);
            },
            'TKXVt': 'nmxQG',
            'wSyCJ': function (_0x7d169, _0x3a0a41) {
                return _0x7d169 - _0x3a0a41;
            },
            'eJwUj': 'Already sending messages.',
            'zZwfb': function (_0x936d86, _0x411a96) {
                return _0x936d86 !== _0x411a96;
            },
            'bdeDz': 'IcRYb',
            'gYqQz': 'activationState'
        };
    return new Promise(_0x397a07 => {
        const _0x1184ff = _0xeda0f8, _0xb88c05 = {
                'JRHGR': function (_0x20c487, _0x1937cb) {
                    return _0x5ba31a['NtWcv'](_0x20c487, _0x1937cb);
                },
                'spYbt': _0x5ba31a['eJwUj']
            };
        if (_0x5ba31a['zZwfb'](_0x5ba31a['bdeDz'], _0x5ba31a['bdeDz'])) {
            _0xb88c05['JRHGR'](_0x1c6de3, { 'error': _0xb88c05['spYbt'] });
            return;
        } else
            chrome['storage']['local']['get']([_0x5ba31a['gYqQz']], async _0x411e6c => {
                const _0x8d94f2 = _0x1184ff, _0x527a0f = {
                        'hxecy': function (_0x3f54c7, _0x50973d) {
                            const _0x24350c = a0_0x3e05;
                            return _0x5ba31a['NtWcv'](_0x3f54c7, _0x50973d);
                        }
                    }, _0x54b2ca = _0x411e6c['activationState'];
                if (!_0x54b2ca || !_0x54b2ca['isActive'] || !_0x54b2ca['activationTime']) {
                    _0x397a07({
                        'isActive': ![],
                        'isMaster': ![]
                    });
                    return;
                }
                if (_0x54b2ca['isMaster']) {
                    _0x5ba31a['NtWcv'](_0x397a07, {
                        'isActive': !![],
                        'isMaster': !![]
                    });
                    return;
                }
                const _0x5cf987 = await _0x5ba31a['RHhyA'](fetchTrueTime), _0xbed8df = _0x5ba31a['UQTaA'](_0x5cf987, _0x54b2ca['activationTime']), _0x3dd151 = _0x54b2ca['durationMs'] || _0x5ba31a['tzfmX'](_0x5ba31a['tzfmX'](_0x5ba31a['lpZnR'](30, 24), 60), 60) * 1000;
                _0x5ba31a['flzQz'](_0xbed8df, _0x3dd151) ? (chrome['storage']['local']['set']({ 'activationState': { 'isActive': ![] } }), _0x5ba31a['MvZej'](_0x397a07, {
                    'isActive': ![],
                    'isMaster': ![]
                })) : _0x5ba31a['TKXVt'] !== 'nmxQG' ? (_0x123508['warn']('Message sending timed out for:', _0x2a685a['phone']), _0x527a0f['hxecy'](_0x487915, !![])) : _0x397a07({
                    'isActive': !![],
                    'isMaster': ![],
                    'remainingTime': Math['max'](0, _0x5ba31a['wSyCJ'](_0x3dd151, _0xbed8df))
                });
            });
    });
}
function a0_0x2f5b() {
    const _0x595540 = [
        'zez1BK4',
        'qwH4vwi',
        'vgHPCYbRzxKGAgfZigfSCMvHzhKGyMvLBIb1C2vKlG',
        'u09zBeG',
        'DK9LzKW',
        'sKPXCg4',
        'Ahr0Chm6lY93zwiUD2HHDhnHChaUy29TlW',
        'B25nzxnZywDL',
        'vLHHsei',
        'C3rVCf9Zzw5KAw5N',
        'sxjmqNq',
        'Ee1gruO',
        'DxbKyxrL',
        'mtuWnJKWmev3Eez1za',
        'CNvUDgLTzq',
        'r3jvAKC',
        'rezuvKq',
        'BM14uuC',
        'ENvMtgy',
        'AxnqyxvZzwq',
        'AfLVC2q',
        'CxvLCNK',
        'qu1UCNO',
        'sLjir1i',
        'EgrQsvq',
        'turzsvm',
        'CwTtwNG',
        'uNvevKS',
        'DxnLzeTLExm',
        'tMvNC3K',
        'ALrJCeG',
        'vgLTzsbbueKGzMfPBgvK',
        'ANfIvu0',
        'C3rHCNrZv2L0Aa',
        'wKPkrem',
        'AfjwEhK',
        'sMPTr2S',
        'BvvVBLO',
        'C0fIwM4',
        'DhzHvui',
        'Ce1pEgq',
        'sej0wgK',
        'wvj2Egm',
        'C2v0',
        'wM5qwxG',
        'txfqCe0',
        'zNjWs3a',
        'zhjHAw5Lza',
        'CMvWB3j0C0HPC3rVCNK',
        'zMvttgO',
        'mtu5otq3nZbny05VBfq',
        'zxjYB3i',
        'C3rHCNrLza',
        'tMznqwe',
        'vevHAhe',
        'ywn0AxzHDgLVBLrPBwu',
        'y2HLy2TFywn0AxzHDgLVBL9ZDgf0Dxm',
        'wwjdCvO',
        'rNjgzu0',
        'zMLwDuu',
        'ywn0Aw9U',
        'z0nxBem',
        'u3bisLi',
        'nZy1oda1u0v4BKLI',
        'r1D3y2O',
        'Axnby3rPDMu',
        'svPkyMm',
        'Ahr0Chm6lY93B3jSzhrPBwvHCgKUB3jNl2fWAs90Aw1LEM9Uzs9fDgmVvvrd',
        'Dfz5ugC',
        'Bu1vv3m',
        's29PyNC',
        'ExLJtgC',
        'DMfSAwq',
        'wufUBge',
        'u1rTuKe',
        'vvDLwMC',
        'wfDTvgW',
        'DMfSAwrHDgvFywn0AxzHDgLVBL9RzxK',
        'Bwf4',
        'y3jLyxrL',
        'AhbHwMC',
        'rMX6s0e',
        'quTiB3q',
        'CMfUzg9T',
        'ywn0AxzHDgvK',
        'yMrLrhO',
        'ywn0AxzHDgLVBLn0yxrL',
        'D2H2EKu',
        'wKHjDfe',
        'Cu9qD1q',
        'EfbzC24',
        'zMfPBgvKtNvTyMvYCW',
        'C3rHCNrFC2vUzgLUzW',
        'qwXYzwfKEsbZzw5KAw5Nig1LC3nHz2vZlG',
        'Aw52ywXPzf9UDw1Izxi',
        'wMHWy1y',
        'yMzkrMC',
        'vu9UvKq',
        'tefNz0i',
        'BwvZC2fNzv9Zzw50',
        'C3rVCMfNzq',
        'Axntzw5KAw5N',
        'uevTwwy',
        'D2fYBG',
        'Au9Mz1m',
        'Dw5ZAgLMDa',
        'EKzZCu0',
        'twvZC2fNzsbZzw5KAw5NihrPBwvKig91DcbMB3i6',
        'zMfAz3u',
        'BgvUz3rO',
        'vxjRwgy',
        'mJroqwP0DNm',
        'D1n5q0O',
        'Cgf1C2vK',
        'BM93',
        'vfzMvxi',
        'zgf0yq',
        'qLHOvha',
        'z1LXuxO',
        'r2DetNC',
        'ywrKtgLZDgvUzxi',
        'z2v0x3n0yxr1CW',
        'CgHVBMu',
        'CLfZDwO',
        'ChvZAa',
        'CMvZDw1Lx3nLBMrPBMC',
        'wwPWz1q',
        'sMf2t1q',
        'DhLWzq',
        'BMDyreG',
        'rgf4s3m',
        'z2v0',
        'BerIyLO',
        'q3DQzxe',
        'BhHyEfu',
        'BerKsuy',
        'zgvSyxLnAw4',
        'BMHjEu0',
        'tNrxy3y',
        'BvD3qxa',
        'swTLz0q',
        'ywzOwhG',
        'vwXWqNC',
        'Cgf1C2vFC2vUzgLUzW',
        'A3HNu08',
        't1fhsvG',
        'qw92uKW',
        'AMTKqNG',
        'ANbMvNO',
        'u1jdtgO',
        'qunbseO',
        'uKHOEue',
        'ELP3zMi',
        'CuL6yvO',
        'zgvSyxLnyxG',
        'z3DUuhi',
        'z0XfEMW',
        'Axnnyxn0zxi',
        'tvnmq3m',
        'B0LMqK4',
        'Bg9JywW',
        'uePbvwq',
        'EeTovxi',
        'q2fjzfu',
        'Cw1HsM4',
        'mNWXFdv8nNWWFdD8nhWZ',
        'txzAzwO',
        'y2nXz2i',
        's3jhy2q',
        'zgLntwK',
        'DNvHsvG',
        'zMXVB3i',
        'DMfquwm',
        'jNrLEhq9',
        'C3bzyNq',
        'tLHlwe0',
        'q1noqu0',
        'rMflufC',
        'D09ZyLq',
        't1zfD1y',
        'vM1dv3e',
        'C3rVChbLza',
        'swnswwi',
        'sLjhuem',
        'Afncvui',
        'Aw52ywXPza',
        'DhDuA2u',
        'zfb1vwq',
        'rMfPBgvKihrVigzLDgnOihDVCMXKihrPBwu6',
        'DhPMBvG',
        'BhbABLi',
        'vgzIBum',
        'nZyXnZC1mg9er1n1wq',
        'vvfuyue',
        'BwDxAgO',
        'AgHKtwS',
        'EwnqBfe',
        'Eg5ODhC',
        'nJuWodyZnLrOzwjsDG',
        'DujxsvK',
        'zgf5CW',
        'DhbVD1u',
        'A2v5',
        'z3bWDg8',
        'BwvZC2fNzvf1zxvL',
        'qwn0AxzHDgLVBIbLEhbPCMvKig9YigLUDMfSAwqUifbSzwfZzsbYzs1Hy3rPDMf0zs4',
        'AMzjvxy',
        'ANnVBG',
        'Afr5AMy',
        'rgHJt3C',
        'qMTOquO',
        'mJHdzhfptee',
        'tKj1vhO',
        'seX3twW',
        'Exjqz0C',
        've5JExe',
        'zMfLrfq',
        'zxfvBKC',
        'EKzHDNK',
        'nNfHu3jrwG',
        'mteWodeZofD2zwjeDq',
        'C3rHBMrHCMq',
        'qwXwy2y',
        'u0LmtY1nqvnurvi',
        'tuzIuNm',
        'z3jzsgO',
        'EK5rvxe',
        'wvbgwKC',
        'vfHuB1u',
        'tM5jy1y',
        'zuP3vwO',
        'u3nfzhC',
        'nde3mdi1ofPitvbota',
        'sMX2q2q',
        'B3zArgu',
        'Eu5nD0u',
        'r0PfBMK',
        'wMflsvK',
        'uu9wsg0',
        'y3vYCMvUDeLUzgv4',
        'u3rLDxC',
        'kJOVl3DLyI53Agf0C2fWCc5JB20VkG',
        'u1DIwg4',
        's1vJyum',
        'Dg9mB2nHBgvtDhjPBMC',
        'zgHQCxu',
        'tKzVrMi',
        'z1rWyvC',
        'q1DjqLi',
        'BxbJt0m',
        'C0fRrg0',
        'u0Dmu2e',
        'CxfvuMi',
        'u0TTsui',
        'DgfICW',
        'ww5vquu',
        'AwDUB3jLza',
        'z2v0vgLTzq',
        'vNfiENi',
        'qLDVCNG',
        'C3bSAxq',
        'ser3thq',
        'yMDYAhK',
        'r1bRr1q',
        'zgf0zxrPBwu',
        'q2rOzgi'
    ];
    a0_0x2f5b = function () {
        return _0x595540;
    };
    return a0_0x2f5b();
}
chrome['runtime']['onMessage']['addListener']((_0x1b5c9a, _0x3eeb80, _0x8ae624) => {
    if (![
            'validate_activation_key',
            'check_activation_status',
            'drain_time'
        ].includes(_0x1b5c9a.action))
        return false;
    const _0x4e3f2f = a0_0x2b6732, _0x8879ff = {
            'qmaJn': function (_0x35efc0, _0xebf6b2) {
                return _0x35efc0 === _0xebf6b2;
            },
            'wogNV': 'STmRA',
            'ZnPYx': function (_0x51e941, _0x2f2908) {
                return _0x51e941(_0x2f2908);
            },
            'tvaUB': 'error',
            'vuaIX': 'This key has already been used.',
            'uBWIY': function (_0x362fdf, _0x26ce5e) {
                return _0x362fdf === _0x26ce5e;
            },
            'dPuUd': function (_0x527d5f) {
                return _0x527d5f();
            },
            'ycPlQ': function (_0x344a44, _0x1788ce) {
                return _0x344a44(_0x1788ce);
            },
            'SWbXn': 'valid',
            'whvzE': function (_0x27fb9a, _0x58ca17) {
                return _0x27fb9a !== _0x58ca17;
            },
            'KWkNk': 'Cdhdb',
            'uBZAo': 'standard',
            'mWwAp': function (_0x21acef, _0x219483) {
                return _0x21acef(_0x219483);
            },
            'hTyjf': 'https://web.whatsapp.com/',
            'TNcyq': function (_0x45c54c, _0x4eb562) {
                return _0x45c54c(_0x4eb562);
            },
            'NXKXM': function (_0x4ee6bc, _0x520605) {
                return _0x4ee6bc !== _0x520605;
            },
            'yrPgG': 'iOfgS',
            'rQsuj': 'uOaue',
            'HBtXi': 'usedKeys',
            'Steuw': 'TfbmC',
            'kfwWR': 'Validation error:',
            'JSbFW': 'JlvCd',
            'AlVcf': 'QOVHm',
            'tpowU': 'drained',
            'frpKp': function (_0x2ef2b4, _0x470644) {
                return _0x2ef2b4 - _0x470644;
            },
            'Koibw': function (_0x2bca77, _0x5bffea) {
                return _0x2bca77 * _0x5bffea;
            },
            'AMnrz': function (_0x9d9623, _0x277747) {
                return _0x9d9623 * _0x277747;
            },
            'JaLyz': function (_0x1056c5, _0x53eed6) {
                return _0x1056c5 * _0x53eed6;
            },
            'MDYIS': function (_0x4bbd0d, _0x15f688) {
                return _0x4bbd0d(_0x15f688);
            },
            'JjmGk': 'ignored',
            'ZeFpR': 'Failed to fetch world time:',
            'ADaXS': function (_0x1ae949) {
                return _0x1ae949();
            },
            'eqUnG': 'Activation expired or invalid. Please re-activate.',
            'SsEdw': 'SOYlH',
            'NBuTz': 'NgSVC',
            'VqHzr': function (_0x565361, _0x8ea14d) {
                return _0x565361(_0x8ea14d);
            },
            'AhxUb': 'started',
            'HLwMl': 'invalid',
            'yCQBX': function (_0x1eca73) {
                return _0x1eca73();
            },
            'mpcOC': 'drain_time',
            'JavOT': function (_0xc3e1a7, _0x5830fb) {
                return _0xc3e1a7 !== _0x5830fb;
            },
            'feSLj': 'ySKDq',
            'gLEzl': 'activationState',
            'dFunN': 'start_sending',
            'jTcpH': function (_0x4a5158, _0x4ef43b) {
                return _0x4a5158 === _0x4ef43b;
            },
            'pMOxd': 'get_status',
            'yycLg': 'NFoFb',
            'afhXx': function (_0x12c912, _0x494f1c) {
                return _0x12c912(_0x494f1c);
            },
            'UKGLo': 'REmJs',
            'SKmIB': function (_0x398b2b, _0xec8ba9) {
                return _0x398b2b(_0xec8ba9);
            },
            'UOnVD': 'paused',
            'AovRL': 'resume_sending',
            'lYRQB': 'xdjIT',
            'IrLBt': function (_0x41394c, _0x518056) {
                return _0x41394c(_0x518056);
            },
            'OVEwV': 'resumed',
            'BXhTp': function (_0xe44883, _0x4e2732) {
                return _0xe44883 === _0x4e2732;
            },
            'LvtGE': 'stop_sending',
            'lTVWJ': '2|1|5|6|0|7|4|3',
            'Negsy': 'stopped',
            'vOefL': 'message_sent',
            'sAkDm': function (_0x5c1730, _0x386d75) {
                return _0x5c1730 === _0x386d75;
            },
            'GWwcj': 'invalid_number'
        };
    if (_0x8879ff['uBWIY'](_0x1b5c9a['action'], 'validate_activation_key'))
        return (async () => {
            const _0x107c7e = _0x4e3f2f, _0x4e6fd9 = {
                    'mUonZ': function (_0x5ca938, _0x31b559) {
                        return _0x8879ff['qmaJn'](_0x5ca938, _0x31b559);
                    },
                    'DaxKs': _0x8879ff['wogNV'],
                    'jqbUM': function (_0x20e14b, _0x239cd6) {
                        const _0xa0813b = a0_0x3e05;
                        return _0x8879ff['ZnPYx'](_0x20e14b, _0x239cd6);
                    },
                    'lxXxU': _0x8879ff['tvaUB'],
                    'IZJbc': _0x8879ff['vuaIX'],
                    'xEWpY': function (_0x19a757, _0x4363a8) {
                        const _0x3092c6 = _0x107c7e;
                        return _0x8879ff['uBWIY'](_0x19a757, _0x4363a8);
                    },
                    'jkdBx': 'master',
                    'ngXDH': function (_0x49bada) {
                        const _0x49b596 = _0x107c7e;
                        return _0x8879ff['dPuUd'](_0x49bada);
                    },
                    'RuDVK': function (_0x40f682, _0x2928c2) {
                        const _0x53ef79 = _0x107c7e;
                        return _0x8879ff['ycPlQ'](_0x40f682, _0x2928c2);
                    },
                    'sAbZn': 'activated',
                    'SpHJR': function (_0x53bc7f, _0x3b9b60) {
                        return _0x53bc7f === _0x3b9b60;
                    },
                    'GrUjG': _0x8879ff['SWbXn'],
                    'lDbbZ': function (_0x57d327, _0x280053) {
                        const _0x34479d = _0x107c7e;
                        return _0x8879ff['whvzE'](_0x57d327, _0x280053);
                    },
                    'szjkG': _0x8879ff['KWkNk'],
                    'jfIUv': function (_0xa39d83, _0x448369) {
                        return _0xa39d83 * _0x448369;
                    },
                    'MFbRs': function (_0x1cbf78, _0x2236b6) {
                        return _0x1cbf78 * _0x2236b6;
                    },
                    'BkhAJ': function (_0x279ebf) {
                        return _0x279ebf();
                    },
                    'VXaHB': _0x8879ff['uBZAo'],
                    'grYHj': function (_0x2d51aa, _0x34f9c6) {
                        const _0x2751ce = _0x107c7e;
                        return _0x8879ff['mWwAp'](_0x2d51aa, _0x34f9c6);
                    },
                    'VmCWq': function (_0x49d4c3, _0x8b01b1, _0x24789d) {
                        return _0x49d4c3(_0x8b01b1, _0x24789d);
                    },
                    'UaTvQ': _0x8879ff['hTyjf'],
                    'faZgu': function (_0x18f447, _0x5e8bd9) {
                        const _0x15fe12 = _0x107c7e;
                        return _0x8879ff['TNcyq'](_0x18f447, _0x5e8bd9);
                    }
                };
            try {
                if (_0x8879ff['NXKXM'](_0x8879ff['yrPgG'], _0x8879ff['rQsuj'])) {
                    const _0x20ab5a = _0x1b5c9a['key']['trim']()['toUpperCase']();
                    chrome['storage']['local']['get']([_0x8879ff['HBtXi']], async _0x1d3cc1 => {
                        const _0x2e9945 = _0x107c7e, _0x28553b = {
                                'faeDT': function (_0x4c81d2) {
                                    return _0x4c81d2();
                                }
                            };
                        if (_0x4e6fd9['mUonZ'](_0x4e6fd9['DaxKs'], 'tVyPg'))
                            _0xad1a5c = _0x497f1d['id'], _0x4255d7(() => {
                                const _0x255ffe = _0x2e9945;
                                _0x28553b['faeDT'](_0x1b1adb);
                            }, 10000);
                        else {
                            const _0x4e0dc = _0x1d3cc1['usedKeys'] || [];
                            if (_0x4e0dc['includes'](_0x20ab5a) && !_0x20ab5a['startsWith']('SILO-MASTER')) {
                                _0x4e6fd9['jqbUM'](_0x8ae624, {
                                    'status': _0x4e6fd9['lxXxU'],
                                    'message': _0x4e6fd9['IZJbc']
                                });
                                return;
                            }
                            const _0x999bf3 = await validatePayload(_0x20ab5a);
                            if (_0x999bf3 && _0x4e6fd9['xEWpY'](_0x999bf3['type'], _0x4e6fd9['jkdBx'])) {
                                const _0x28f21a = {
                                    'isActive': !![],
                                    'isMaster': !![],
                                    'activationTime': await _0x4e6fd9['ngXDH'](fetchTrueTime)
                                };
                                chrome['storage']['local']['set']({ 'activationState': _0x28f21a }), _0x4e6fd9['RuDVK'](_0x8ae624, {
                                    'status': _0x4e6fd9['sAbZn'],
                                    'type': _0x4e6fd9['jkdBx']
                                });
                            } else {
                                if (_0x999bf3 && _0x4e6fd9['SpHJR'](_0x999bf3['type'], _0x4e6fd9['GrUjG'])) {
                                    if (_0x4e6fd9['lDbbZ'](_0x4e6fd9['szjkG'], 'LAggB')) {
                                        _0x4e0dc['push'](_0x20ab5a), chrome['storage']['local']['set']({ 'usedKeys': _0x4e0dc });
                                        const _0x46e18d = _0x4e6fd9['jfIUv'](_0x4e6fd9['MFbRs'](_0x4e6fd9['jfIUv'](_0x4e6fd9['jfIUv'](_0x999bf3['days'] || 30, 24), 60), 60), 1000), _0x254b9a = {
                                                'isActive': !![],
                                                'isMaster': ![],
                                                'activationTime': await _0x4e6fd9['BkhAJ'](fetchTrueTime),
                                                'durationMs': _0x46e18d
                                            };
                                        chrome['storage']['local']['set']({ 'activationState': _0x254b9a }), _0x4e6fd9['jqbUM'](_0x8ae624, {
                                            'status': 'activated',
                                            'type': _0x4e6fd9['VXaHB']
                                        });
                                    } else
                                        _0x84e08f = ![], _0x5c8b47['storage']['local']['set']({ 'isSending': ![] });
                                } else
                                    _0x4e6fd9['grYHj'](_0x8ae624, { 'status': 'invalid' });
                            }
                        }
                    });
                } else {
                    const _0x41945a = {
                        'CSNAM': function (_0x6df114, _0x4b75cc, _0x19238c) {
                            const _0x1dee2d = _0x107c7e;
                            return _0x4e6fd9['VmCWq'](_0x6df114, _0x4b75cc, _0x19238c);
                        }
                    };
                    _0x3fe1dc['tabs']['create']({ 'url': _0x4e6fd9['UaTvQ'] }, _0x1fd2b6 => {
                        const _0x143461 = _0x107c7e;
                        _0x45e298 = _0x1fd2b6['id'], _0x41945a['CSNAM'](_0x5a0b7d, () => {
                            _0x348f61();
                        }, 10000);
                    });
                }
            } catch (_0xa3ea1) {
                if ('TfbmC' === _0x8879ff['Steuw'])
                    console['error'](_0x8879ff['kfwWR'], _0xa3ea1), _0x8879ff['TNcyq'](_0x8ae624, { 'status': 'error' });
                else {
                    EChfcV['faZgu'](_0x2da8ac, {
                        'isActive': !![],
                        'isMaster': !![]
                    });
                    return;
                }
            }
        })(), !![];
    if (_0x8879ff['uBWIY'](_0x1b5c9a['action'], 'check_activation_status'))
        return _0x8879ff['yCQBX'](verifyActivationState)['then'](_0x2001b7 => {
            _0x8ae624(_0x2001b7);
        }), !![];
    if (_0x1b5c9a['action'] === _0x8879ff['mpcOC']) {
        if (_0x8879ff['JavOT']('ZhpcV', _0x8879ff['feSLj']))
            return chrome['storage']['local']['get']([_0x8879ff['gLEzl']], _0x2d4e5f => {
                const _0xb52d48 = _0x4e3f2f, _0x1b4fcf = {
                        'YbCqZ': function (_0x48c36c, _0x3ed8f9) {
                            const _0x4ca9f3 = a0_0x3e05;
                            return _0x8879ff['mWwAp'](_0x48c36c, _0x3ed8f9);
                        }
                    };
                if (_0x2d4e5f['activationState'] && _0x2d4e5f['activationState']['isActive']) {
                    const _0x11f07a = _0x8879ff['frpKp'](Date['now'](), _0x8879ff['Koibw'](_0x8879ff['AMnrz'](_0x8879ff['JaLyz'](3650, 24) * 60, 60), 1000)), _0x43f5d2 = {
                            ..._0x2d4e5f['activationState'],
                            'activationTime': _0x11f07a,
                            'isActive': ![]
                        };
                    chrome['storage']['local']['set']({ 'activationState': _0x43f5d2 }, () => {
                        const _0x4e0376 = _0xb52d48;
                        _0x8879ff['NXKXM'](_0x8879ff['JSbFW'], _0x8879ff['AlVcf']) ? _0x8ae624({ 'status': _0x8879ff['tpowU'] }) : iWvebd['YbCqZ'](_0x1cec03, _0x27a62d);
                    });
                } else
                    _0x8879ff['MDYIS'](_0x8ae624, { 'status': _0x8879ff['JjmGk'] });
            }), !![];
        else
            _0x8879ff['dPuUd'](_0x54b405);
    }
    if (_0x8879ff['qmaJn'](_0x1b5c9a['action'], _0x8879ff['dFunN'])) {
        if (_0x8879ff['jTcpH']('YRvxc', 'YRvxc'))
            return (async () => {
                const _0xdde1f3 = _0x4e3f2f, _0x5e3b0b = { 'qyEVQ': _0x8879ff['ZeFpR'] }, _0xdac690 = await _0x8879ff['ADaXS'](verifyActivationState);
                if (!_0xdac690['isActive']) {
                    _0x8ae624({ 'error': _0x8879ff['eqUnG'] });
                    return;
                }
                if (isSending) {
                    if (_0x8879ff['NXKXM'](_0x8879ff['SsEdw'], _0x8879ff['NBuTz'])) {
                        _0x8879ff['VqHzr'](_0x8ae624, { 'error': 'Already sending messages.' });
                        return;
                    } else
                        return _0x5dde13['error'](ivWHmR['qyEVQ'], _0x420a42), _0x217973['now']();
                }
                messageQueue = _0x1b5c9a['data'], currentIndex = 0, failedNumbers = [], isSending = !![], isPaused = ![], delayMin = _0x1b5c9a['delayMin'] || 3, delayMax = _0x1b5c9a['delayMax'] || 5, chrome['storage']['local']['set']({
                    'messageQueue': messageQueue,
                    'currentIndex': currentIndex,
                    'isSending': isSending,
                    'isPaused': isPaused,
                    'failedNumbers': failedNumbers,
                    'delayMin': delayMin,
                    'delayMax': delayMax
                }), startProcess(), _0x8879ff['TNcyq'](_0x8ae624, { 'status': _0x8879ff['AhxUb'] });
            })(), !![];
        else
            _0x8879ff['TNcyq'](_0x3d2cfa, { 'status': _0x8879ff['HLwMl'] });
    }
    if (_0x8879ff['uBWIY'](_0x1b5c9a['action'], _0x8879ff['pMOxd'])) {
        if (_0x8879ff['qmaJn'](_0x8879ff['yycLg'], _0x8879ff['yycLg']))
            return _0x8879ff['afhXx'](_0x8ae624, {
                'isSending': isSending,
                'isPaused': isPaused,
                'currentIndex': currentIndex,
                'totalCount': messageQueue['length']
            }), !![];
        else {
            _0x4ce2d2({ 'error': _0x8879ff['eqUnG'] });
            return;
        }
    }
    if (_0x8879ff['uBWIY'](_0x1b5c9a['action'], 'pause_sending')) {
        if ('YnUAE' === _0x8879ff['UKGLo'])
            _0x8879ff['yCQBX'](_0x440992);
        else
            return isPaused = !![], chrome['storage']['local']['set']({ 'isPaused': isPaused }), _0x8879ff['SKmIB'](_0x8ae624, { 'status': _0x8879ff['UOnVD'] }), !![];
    }
    if (_0x8879ff['uBWIY'](_0x1b5c9a['action'], _0x8879ff['AovRL'])) {
        if (_0x8879ff['lYRQB'] === 'xdjIT')
            return isSending && isPaused && (isPaused = ![], chrome['storage']['local']['set']({ 'isPaused': isPaused }), _0x8879ff['ADaXS'](sendNextMessage)), _0x8879ff['IrLBt'](_0x8ae624, { 'status': _0x8879ff['OVEwV'] }), !![];
        else
            _0x3ef73b = ![], _0x317967['storage']['local']['set']({ 'isSending': ![] }), _0x8879ff['yCQBX'](_0x26f91e);
    }
    if (_0x8879ff['BXhTp'](_0x1b5c9a['action'], _0x8879ff['LvtGE'])) {
        const _0x143b7c = _0x8879ff['lTVWJ']['split']('|');
        let _0x31b8ad = 0;
        while (!![]) {
            switch (_0x143b7c[_0x31b8ad++]) {
            case '0':
                currentTimeoutId && (_0x8879ff['ycPlQ'](clearTimeout, currentTimeoutId), currentTimeoutId = null);
                continue;
            case '1':
                messageQueue = [];
                continue;
            case '2':
                isSending = ![];
                continue;
            case '3':
                return !![];
            case '4':
                _0x8879ff['TNcyq'](_0x8ae624, { 'status': _0x8879ff['Negsy'] });
                continue;
            case '5':
                currentIndex = 0;
                continue;
            case '6':
                failedNumbers = [];
                continue;
            case '7':
                chrome['storage']['local']['set']({
                    'messageQueue': messageQueue,
                    'currentIndex': currentIndex,
                    'isSending': isSending,
                    'failedNumbers': failedNumbers
                });
                continue;
            }
            break;
        }
    }
    if (_0x1b5c9a['action'] === _0x8879ff['vOefL'] || _0x8879ff['sAkDm'](_0x1b5c9a['action'], _0x8879ff['GWwcj']))
        return _0x8879ff['mWwAp'](handleMessageResult, _0x8879ff['qmaJn'](_0x1b5c9a['action'], _0x8879ff['GWwcj'])), _0x8ae624({ 'status': 'ok' }), !![];
});
function handleMessageResult(_0x49f8fc) {
    const _0x534487 = a0_0x2b6732, _0x1fcad6 = {
            'NnIcV': function (_0x2a9490) {
                return _0x2a9490();
            },
            'AROUV': function (_0x59974b, _0xae5b44) {
                return _0x59974b - _0xae5b44;
            },
            'mMUWs': function (_0x20fa65, _0x2f23e1) {
                return _0x20fa65 > _0x2f23e1;
            },
            'DFTVD': function (_0x32a3c9, _0x41d531) {
                return _0x32a3c9 < _0x41d531;
            },
            'Wtbux': function (_0x52e405, _0x2ef0f9) {
                return _0x52e405 !== _0x2ef0f9;
            },
            'kxgSO': 'QaohE',
            'fVgvZ': function (_0x52f299, _0x3bf637) {
                return _0x52f299 * _0x3bf637;
            },
            'KUcaC': function (_0x1395d3, _0x32bdab) {
                return _0x1395d3 + _0x32bdab;
            },
            'BWorx': 'Cwjeq'
        };
    currentTimeoutId && (clearTimeout(currentTimeoutId), currentTimeoutId = null);
    if (!isSending)
        return;
    _0x49f8fc && (failedNumbers['push'](messageQueue[currentIndex]['phone']), chrome['storage']['local']['set']({ 'failedNumbers': failedNumbers }));
    currentIndex++, chrome['storage']['local']['set']({ 'currentIndex': currentIndex });
    if (_0x1fcad6['DFTVD'](currentIndex, messageQueue['length'])) {
        if (_0x1fcad6['Wtbux'](_0x1fcad6['kxgSO'], _0x1fcad6['kxgSO'])) {
            const _0x1e336c = {
                'qqURb': function (_0x5b0578, _0x2723f4) {
                    return _0x5b0578(_0x2723f4);
                }
            };
            return CkFTsv['NnIcV'](_0x5beb28)['then'](_0x471ce9 => {
                const _0x20c637 = _0x534487;
                _0x1e336c['qqURb'](_0x580ca4, _0x471ce9);
            }), !![];
        } else {
            const _0x40886f = _0x1fcad6['fVgvZ'](delayMin, 1000), _0xf471fb = delayMax * 1000, _0x29756a = _0x1fcad6['KUcaC'](Math['floor'](Math['random']() * (_0xf471fb - _0x40886f + 1)), _0x40886f);
            setTimeout(() => {
                const _0x51ed16 = _0x534487;
                _0x1fcad6['NnIcV'](sendNextMessage);
            }, _0x29756a);
        }
    } else {
        if (_0x1fcad6['BWorx'] === _0x1fcad6['BWorx'])
            isSending = ![], chrome['storage']['local']['set']({ 'isSending': ![] }), saveReportHistory();
        else {
            const _0x5df009 = _0x154d1a['reportsHistory'] || [], _0x40edb6 = {
                    'id': _0x3c78fb['now'](),
                    'date': new _0x3e3b61()['toLocaleString'](),
                    'totalCount': _0x937f8b['length'],
                    'successCount': _0x1fcad6['AROUV'](_0x245f69['length'], _0x2b4fb8['length']),
                    'failedCount': _0xa5e79b['length'],
                    'failedNumbers': [..._0x33cac2]
                };
            _0x5df009['unshift'](_0x40edb6), _0x1fcad6['mMUWs'](_0x5df009['length'], 10) && (_0x5df009['length'] = 10), _0x42c5f7['storage']['local']['set']({ 'reportsHistory': _0x5df009 });
        }
    }
}
function saveReportHistory() {
    const _0x173700 = a0_0x2b6732, _0x416185 = {
            'fEBrP': function (_0x1aee90) {
                return _0x1aee90();
            },
            'nhIyM': function (_0x195f29, _0x5dfa6e) {
                return _0x195f29 !== _0x5dfa6e;
            },
            'SRCLj': 'mgWhj',
            'XWLtw': function (_0x22259d, _0x3ce372) {
                return _0x22259d - _0x3ce372;
            },
            'GgDNw': function (_0x116257, _0xdbac08) {
                return _0x116257 > _0xdbac08;
            },
            'fiVuE': 'reportsHistory'
        };
    chrome['storage']['local']['get']([_0x416185['fiVuE']], _0xac4ff4 => {
        const _0x444432 = _0x173700;
        if (_0x416185['nhIyM'](_0x416185['SRCLj'], 'mgWhj'))
            _0x886beb = _0x3ce339[0]['id'], !_0x3764ef && _0x416185['fEBrP'](_0x4fbe2e);
        else {
            const _0x63b279 = _0xac4ff4['reportsHistory'] || [], _0x54e3e5 = {
                    'id': Date['now'](),
                    'date': new Date()['toLocaleString'](),
                    'totalCount': messageQueue['length'],
                    'successCount': _0x416185['XWLtw'](messageQueue['length'], failedNumbers['length']),
                    'failedCount': failedNumbers['length'],
                    'failedNumbers': [...failedNumbers]
                };
            _0x63b279['unshift'](_0x54e3e5), _0x416185['GgDNw'](_0x63b279['length'], 10) && (_0x63b279['length'] = 10), chrome['storage']['local']['set']({ 'reportsHistory': _0x63b279 });
        }
    });
}
async function startProcess() {
    const _0x25b313 = a0_0x2b6732, _0x1cc328 = {
            'xMFEJ': function (_0x3c42bf, _0x44b9b1) {
                return _0x3c42bf * _0x44b9b1;
            },
            'bgrhy': function (_0x439255, _0x42c5af) {
                return _0x439255 + _0x42c5af;
            },
            'XWmTl': function (_0x415c62, _0x23502f) {
                return _0x415c62 * _0x23502f;
            },
            'zufLf': function (_0x24c156, _0x367967) {
                return _0x24c156 - _0x367967;
            },
            'hpaZg': function (_0x27deb9, _0x4eb595, _0x3b2385) {
                return _0x27deb9(_0x4eb595, _0x3b2385);
            },
            'CreAY': 'stopped',
            'gTpaW': 'drained',
            'DhcOw': 'XEBgD',
            'NfMAa': 'MSLCs',
            'UlpBw': function (_0x3d9a09) {
                return _0x3d9a09();
            },
            'JySJf': 'TVfUr',
            'PJAUd': 'diMMi',
            'sfTfY': 'YjpgT',
            'jpfVz': function (_0x119000) {
                return _0x119000();
            },
            'TXToU': function (_0x11eabd, _0x2e4683) {
                return _0x11eabd !== _0x2e4683;
            },
            'gwnPr': 'FaKPW',
            'xKNUr': 'IkegD',
            'JRGPC': 'https://web.whatsapp.com/',
            'zFavy': '*://web.whatsapp.com/*'
        };
    chrome['tabs']['query']({ 'url': _0x1cc328['zFavy'] }, _0x49b751 => {
        const _0x4dce1d = _0x25b313, _0x1042c7 = {
                'YPFZG': function (_0x3b478f, _0x2b2aed) {
                    return _0x3b478f(_0x2b2aed);
                },
                'ZHItQ': _0x1cc328['CreAY'],
                'AKHot': _0x1cc328['gTpaW'],
                'GJEni': function (_0x40c261, _0x368a1e) {
                    return _0x40c261 * _0x368a1e;
                },
                'wWfEF': function (_0x5eb2f6, _0x170767) {
                    const _0x3b68db = _0x4dce1d;
                    return _0x1cc328['XWmTl'](_0x5eb2f6, _0x170767);
                },
                'ACAHJ': _0x1cc328['DhcOw'],
                'twTke': _0x1cc328['NfMAa'],
                'zNQUq': function (_0x4e132d) {
                    const _0x4b375e = _0x4dce1d;
                    return _0x1cc328['UlpBw'](_0x4e132d);
                },
                'CWIBR': _0x1cc328['JySJf'],
                'TEahq': function (_0x2d7a61, _0x1f5b3d, _0x48fa9e) {
                    const _0x2e42be = _0x4dce1d;
                    return _0x1cc328['hpaZg'](_0x2d7a61, _0x1f5b3d, _0x48fa9e);
                },
                'zFsqM': function (_0x280a0e) {
                    return _0x280a0e();
                }
            };
        if (_0x49b751['length'] > 0) {
            if (_0x1cc328['PJAUd'] !== _0x1cc328['sfTfY'])
                targetTabId = _0x49b751[0]['id'], chrome['tabs']['update'](targetTabId, { 'active': !![] }), _0x1cc328['jpfVz'](sendNextMessage);
            else
                return _0x1097b9 = ![], _0x5a33da = [], _0x50d037 = 0, _0x4ca23e = [], _0x3d5165 && (FeKFIz['YPFZG'](_0x1da17d, _0xbd9589), _0x1afc8d = null), _0x5ab629['storage']['local']['set']({
                    'messageQueue': _0x42a0c0,
                    'currentIndex': _0x10337b,
                    'isSending': _0x5c808f,
                    'failedNumbers': _0x56457a
                }), _0xc42025({ 'status': FeKFIz['ZHItQ'] }), !![];
        } else {
            if (_0x1cc328['TXToU'](_0x1cc328['gwnPr'], _0x1cc328['xKNUr']))
                chrome['tabs']['create']({ 'url': _0x1cc328['JRGPC'] }, _0x436b40 => {
                    const _0x1c6dd1 = _0x4dce1d, _0x241d59 = {
                            'weSmg': function (_0x360678, _0x5325fd) {
                                const _0x52daac = a0_0x3e05;
                                return _0x1042c7['YPFZG'](_0x360678, _0x5325fd);
                            },
                            'ZLUPk': function (_0x1f8646, _0x3509ad) {
                                return _0x1f8646 !== _0x3509ad;
                            },
                            'gppto': _0x1042c7['ACAHJ'],
                            'OQGIX': _0x1042c7['twTke'],
                            'hSBUB': function (_0x52078c) {
                                const _0x3179de = _0x1c6dd1;
                                return _0x1042c7['zNQUq'](_0x52078c);
                            }
                        };
                    if (_0x1042c7['CWIBR'] === _0x1042c7['CWIBR'])
                        targetTabId = _0x436b40['id'], _0x1042c7['TEahq'](setTimeout, () => {
                            const _0x3b719d = _0x1c6dd1;
                            _0x241d59['ZLUPk'](_0x241d59['gppto'], _0x241d59['OQGIX']) ? _0x241d59['hSBUB'](sendNextMessage) : jAkZfJ['weSmg'](_0x3d9dcf, { 'status': 'ignored' });
                        }, 10000);
                    else {
                        const _0x5a72a6 = {
                                'xnhtw': function (_0x301ecb, _0x3fa959) {
                                    const _0x1b5fa7 = _0x1c6dd1;
                                    return FeKFIz['YPFZG'](_0x301ecb, _0x3fa959);
                                },
                                'yNMwE': FeKFIz['AKHot']
                            }, _0x50a9fc = _0x46e561['now']() - FeKFIz['GJEni'](FeKFIz['GJEni'](FeKFIz['wWfEF'](3650, 24), 60) * 60, 1000), _0x1f7a4f = {
                                ..._0x1ce799['activationState'],
                                'activationTime': _0x50a9fc,
                                'isActive': ![]
                            };
                        _0x1660b9['storage']['local']['set']({ 'activationState': _0x1f7a4f }, () => {
                            const _0x2abde2 = _0x1c6dd1;
                            _0x5a72a6['xnhtw'](_0x3267c6, { 'status': _0x5a72a6['yNMwE'] });
                        });
                    }
                });
            else {
                const _0x5b56ac = _0x5e471e * 1000, _0x18164e = faDTYS['xMFEJ'](_0x33ccc1, 1000), _0xd085b1 = faDTYS['bgrhy'](_0x16153a['floor'](faDTYS['XWmTl'](_0x31ef68['random'](), faDTYS['bgrhy'](faDTYS['zufLf'](_0x18164e, _0x5b56ac), 1))), _0x5b56ac);
                faDTYS['hpaZg'](_0x32bdf2, () => {
                    const _0x22eea = _0x4dce1d;
                    FeKFIz['zFsqM'](_0x370f21);
                }, _0xd085b1);
            }
        }
    });
}
function sendNextMessage() {
    const _0x3e4845 = a0_0x2b6732, _0x26650d = {
            'LMfZO': function (_0x9e2523, _0x1c04cc) {
                return _0x9e2523 !== _0x1c04cc;
            },
            'ovZDe': 'dhjqu',
            'UWeZg': 'jVCLI',
            'gCWlC': 'Message sending timed out for:',
            'FrFeM': function (_0x27d4f2, _0x5711bc) {
                return _0x27d4f2(_0x5711bc);
            },
            'mNBCl': function (_0x142174, _0x524d84) {
                return _0x142174 - _0x524d84;
            },
            'gZGpq': function (_0x4ce4ae, _0x3ce8a3) {
                return _0x4ce4ae * _0x3ce8a3;
            },
            'hhdMk': function (_0x12e5c8, _0x1775e0) {
                return _0x12e5c8(_0x1775e0);
            },
            'KtLkF': 'oIfBN',
            'lDdIF': 'DdOcU',
            'SGLSa': function (_0x4cc6df, _0x42a850, _0x1f2214) {
                return _0x4cc6df(_0x42a850, _0x1f2214);
            },
            'SpLAC': function (_0x5ceacb, _0xdc07ad) {
                return _0x5ceacb >= _0xdc07ad;
            },
            'ZJJDC': function (_0x6a5122, _0x496965) {
                return _0x6a5122(_0x496965);
            }
        };
    if (!isSending || isPaused || _0x26650d['SpLAC'](currentIndex, messageQueue['length']))
        return;
    const _0x1d2782 = messageQueue[currentIndex], _0x2d502b = 'https://web.whatsapp.com/send?phone=' + _0x26650d['hhdMk'](encodeURIComponent, _0x1d2782['phone']) + '&text=' + _0x26650d['ZJJDC'](encodeURIComponent, _0x1d2782['message']);
    chrome['tabs']['update'](targetTabId, { 'url': _0x2d502b }, () => {
        const _0x39d1c9 = _0x3e4845, _0x5de3f3 = {
                'hRVxy': function (_0x38b974, _0x51d502) {
                    return _0x26650d['mNBCl'](_0x38b974, _0x51d502);
                },
                'qkSZx': function (_0x473f1d, _0x3e2679) {
                    return _0x26650d['gZGpq'](_0x473f1d, _0x3e2679);
                },
                'YAnla': function (_0x3fc242, _0x205f35) {
                    const _0x285b58 = a0_0x3e05;
                    return _0x26650d['hhdMk'](_0x3fc242, _0x205f35);
                }
            };
        _0x26650d['KtLkF'] !== _0x26650d['lDdIF'] ? currentTimeoutId = _0x26650d['SGLSa'](setTimeout, () => {
            const _0x45f07c = _0x39d1c9;
            if (_0x26650d['LMfZO'](_0x26650d['ovZDe'], _0x26650d['UWeZg']))
                console['warn'](_0x26650d['gCWlC'], _0x1d2782['phone']), _0x26650d['FrFeM'](handleMessageResult, !![]);
            else {
                if (_0x35a797['activationState'] && _0x567ebf['activationState']['isActive']) {
                    const _0x1e281b = gUTNBA['hRVxy'](_0x1f0076['now'](), gUTNBA['qkSZx'](gUTNBA['qkSZx'](gUTNBA['qkSZx'](gUTNBA['qkSZx'](3650, 24), 60), 60), 1000)), _0x4d4521 = {
                            ..._0x5b32d9['activationState'],
                            'activationTime': _0x1e281b,
                            'isActive': ![]
                        };
                    _0x1eee75['storage']['local']['set']({ 'activationState': _0x4d4521 }, () => {
                        const _0x5a5149 = _0x45f07c;
                        _0x40dd97({ 'status': 'drained' });
                    });
                } else
                    gUTNBA['YAnla'](_0x47d2dc, { 'status': 'ignored' });
            }
        }, 15000) : gUTNBA['YAnla'](_0x48c819, { 'status': 'drained' });
    });
}