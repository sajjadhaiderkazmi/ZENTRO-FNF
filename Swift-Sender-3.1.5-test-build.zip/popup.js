const a0_0x3c9c40 = a0_0x1f3f;
(function (_0x4b24a0, _0x5c5610) {
    const _0x6f10d3 = a0_0x1f3f, _0x4b6ed1 = _0x4b24a0();
    while (!![]) {
        try {
            const _0x37d55f = -parseInt('343438PVlBPU') / 1 + -parseInt('359872FRvMaf') / 2 * (parseInt('3rbqGPC') / 3) + parseInt('559372NjQFcv') / 4 * (parseInt('5IAOsqT') / 5) + parseInt('6jveKSo') / 6 * (parseInt('1660449uAwTOh') / 7) + parseInt('1096LGptAK') / 8 * (-parseInt('35541JaEexn') / 9) + parseInt('22870jCeWlG') / 10 * (-parseInt('1925YRWync') / 11) + parseInt('16370388djHTcu') / 12;
            if (_0x37d55f === _0x5c5610)
                break;
            else
                _0x4b6ed1['push'](_0x4b6ed1['shift']());
        } catch (_0x4868af) {
            _0x4b6ed1['push'](_0x4b6ed1['shift']());
        }
    }
}(a0_0x48a6, 276637));
let parsedData = [];
document['getElementById']('file-upload')['addEventListener']('change', handleFile), document['getElementById']('start-btn')['addEventListener']('click', startSending);
function updateFileNameDisplay(_0x7776ce) {
    const _0x444171 = a0_0x3c9c40, _0x5a63b9 = {
            'fZiWT': 'data:text/csv;charset=utf-8,CN Number,COD Amount,Consignee Name,Phone Number\n123456789,1500,Ali Khan,923001234567\n987654321,2500,Usman Ali,923007654321',
            'cMnvM': function (_0x375c10, _0x20a49a) {
                return _0x375c10(_0x20a49a);
            },
            'gwitU': 'href',
            'BORvJ': 'download',
            'YwAiq': 'silo_sample.csv',
            'JbEbo': 'file-name-display',
            'xLDgL': 'var(--text-color)',
            'LYevL': function (_0x356dd3, _0xf4cc08) {
                return _0x356dd3 === _0xf4cc08;
            },
            'xdGBx': 'GgKkV',
            'JxYUu': 'No file selected',
            'siDJJ': 'var(--info-color)'
        }, _0x249ff0 = document['getElementById'](_0x5a63b9['JbEbo']);
    if (_0x7776ce)
        _0x249ff0['textContent'] = _0x7776ce['name'], _0x249ff0['style']['color'] = _0x5a63b9['xLDgL'], _0x249ff0['style']['fontWeight'] = '600';
    else {
        if (_0x5a63b9['LYevL']('GgKkV', _0x5a63b9['xdGBx']))
            _0x249ff0['textContent'] = _0x5a63b9['JxYUu'], _0x249ff0['style']['color'] = _0x5a63b9['siDJJ'], _0x249ff0['style']['fontWeight'] = 'normal';
        else {
            _0x166e8d['preventDefault']();
            const _0x1f7372 = _0x5a63b9['fZiWT'], _0xf1ca78 = _0x5a63b9['cMnvM'](_0x1cf621, _0x1f7372), _0x12d7b4 = _0x27e815['createElement']('a');
            _0x12d7b4['setAttribute'](_0x5a63b9['gwitU'], _0xf1ca78), _0x12d7b4['setAttribute'](_0x5a63b9['BORvJ'], _0x5a63b9['YwAiq']), _0x575428['body']['appendChild'](_0x12d7b4), _0x12d7b4['click'](), _0x1074cc['body']['removeChild'](_0x12d7b4);
        }
    }
}
document['getElementById']('download-sample')['addEventListener']('click', downloadSampleCSV), document['getElementById']('stop-btn')['addEventListener']('click', stopSending), document['getElementById']('pause-btn')['addEventListener']('click', pauseSending), document['getElementById']('resume-btn')['addEventListener']('click', resumeSending), document['getElementById']('report-btn')['addEventListener']('click', openReport);
const activateBtn = document['getElementById']('activate-btn'), eulaCheckbox = document['getElementById']('eula-checkbox');
eulaCheckbox['addEventListener']('change', _0x14bd3a => {
    const _0x53a662 = a0_0x3c9c40, _0x1477de = {
            'lJdrK': 'binary',
            'IpBVh': 'pointer',
            'qvUzf': function (_0x1543df, _0x3dc7e5) {
                return _0x1543df !== _0x3dc7e5;
            },
            'PnZze': 'DRuAE',
            'sTwSq': 'not-allowed'
        };
    if (_0x14bd3a['target']['checked'])
        activateBtn['disabled'] = ![], activateBtn['style']['opacity'] = '1', activateBtn['style']['cursor'] = _0x1477de['IpBVh'];
    else {
        if (_0x1477de['qvUzf']('toFwQ', _0x1477de['PnZze']))
            activateBtn['disabled'] = !![], activateBtn['style']['opacity'] = '0.5', activateBtn['style']['cursor'] = _0x1477de['sTwSq'];
        else {
            const _0x48b7a7 = _0x5bd46a['read'](_0x4b8329, { 'type': _0x1477de['lJdrK'] }), _0x48d950 = _0x48b7a7['SheetNames'][0], _0x412c6e = _0x48b7a7['Sheets'][_0x48d950], _0x2ada4f = _0x524497['utils']['sheet_to_json'](_0x412c6e, { 'header': 1 });
            _0x12de44(_0x2ada4f);
        }
    }
}), activateBtn['addEventListener']('click', handleActivation), document['getElementById']('drain-time-btn')['addEventListener']('click', handleDrainTime);
const templateInput = document['getElementById']('template-input'), campaignSelect = document['getElementById']('campaign-select'), saveCampaignBtn = document['getElementById']('save-campaign-btn'), activationView = document['getElementById']('activation-view'), mainAppView = document['getElementById']('main-app-view'), activationStatus = document['getElementById']('activation-status'), countdownFooter = document['getElementById']('countdown-footer');
let countdownInterval = null;
function formatTime(_0x468150) {
    const _0x444be3 = a0_0x3c9c40, _0x243bf3 = {
            'CPqmK': function (_0x29f84b, _0x29dbc1) {
                return _0x29f84b / _0x29dbc1;
            },
            'HJCJY': function (_0x2ddbce, _0x1bf81a) {
                return _0x2ddbce % _0x1bf81a;
            },
            'ilwVz': function (_0x336d6e, _0xe6a3b7) {
                return _0x336d6e % _0xe6a3b7;
            },
            'cDcBT': function (_0x2cb638, _0x167b3f) {
                return _0x2cb638(_0x167b3f);
            },
            'EtlmW': function (_0x5485aa, _0x52430e) {
                return _0x5485aa(_0x52430e);
            }
        }, _0x23df70 = Math['floor'](_0x243bf3['CPqmK'](_0x468150, 1000)), _0x359d1b = Math['floor'](_0x243bf3['CPqmK'](_0x23df70, 3600)), _0x21fa2e = Math['floor'](_0x243bf3['CPqmK'](_0x243bf3['HJCJY'](_0x23df70, 3600), 60)), _0x4a5669 = _0x243bf3['ilwVz'](_0x23df70, 60);
    return _0x243bf3['cDcBT'](String, _0x359d1b)['padStart'](2, '0') + ':' + _0x243bf3['cDcBT'](String, _0x21fa2e)['padStart'](2, '0') + ':' + _0x243bf3['EtlmW'](String, _0x4a5669)['padStart'](2, '0');
}
function startCountdown(_0x6aa9c4) {
    const _0x4ea2eb = a0_0x3c9c40, _0x29e78d = {
            'hHspC': 'pause-btn',
            'bdUCr': 'none',
            'uEUTe': 'resume-btn',
            'bnfVM': 'block',
            'ZCvYi': 'Sending paused.',
            'VXDul': function (_0x44589a, _0x3925a9) {
                return _0x44589a(_0x3925a9);
            },
            'KWXuP': 'ZognY',
            'GsQQD': function (_0x24fe43, _0x1d9c3c) {
                return _0x24fe43 === _0x1d9c3c;
            },
            'eGlWi': 'pZRMf',
            'ZOUin': '4|2|0|3|1',
            'KHsjT': '#ef4444',
            'tNeGq': function (_0x2d1d16) {
                return _0x2d1d16();
            },
            'AnibI': function (_0x352f22, _0x1b6a1e, _0x103653) {
                return _0x352f22(_0x1b6a1e, _0x103653);
            }
        };
    if (countdownInterval)
        _0x29e78d['VXDul'](clearInterval, countdownInterval);
    let _0x394fb9 = _0x6aa9c4;
    const _0x59f9bd = () => {
        const _0x4e1941 = _0x4ea2eb, _0x3e5e94 = {
                'mmNnq': function (_0x2da96d, _0x2d4fb7) {
                    const _0x4e501d = a0_0x1f3f;
                    return _0x29e78d['VXDul'](_0x2da96d, _0x2d4fb7);
                }
            };
        if (_0x29e78d['KWXuP'] === 'ZognY') {
            if (_0x394fb9 <= 0) {
                if (_0x29e78d['GsQQD']('tRcPU', _0x29e78d['eGlWi'])) {
                    const _0x4df42d = _0x4b64a1[_0x34b15b];
                    if (_0x4df42d && _0x4df42d['length'] > _0x26766a['max'](_0x16947b, _0x25ae9f, _0x567957, _0x1d6097)) {
                        const _0x2c12b5 = _0x467e6a(_0x4df42d[_0x431894] || '')['trim'](), _0x2be8f1 = _0x3e5e94['mmNnq'](_0x1d37b5, _0x4df42d[_0x39155a] || '')['trim'](), _0x2e2fac = _0x265507(_0x4df42d[_0x542578] || '')['trim'](), _0x512ff9 = _0x2d25e1(_0x4df42d[_0x4700fc] || '')['trim']();
                        if (_0x512ff9) {
                            let _0x1393d6 = _0x37589b;
                            _0x1393d6 = _0x1393d6['replace'](/{Consignee Name}/ig, _0x2e2fac), _0x1393d6 = _0x1393d6['replace'](/{CN Number}/ig, _0x2c12b5), _0x1393d6 = _0x1393d6['replace'](/{COD Amount}/ig, _0x2be8f1);
                            const _0x239de8 = _0x512ff9['replace'](/[\s\-()]/g, '');
                            _0xb72811['push']({
                                'phone': _0x239de8,
                                'message': _0x1393d6
                            });
                        }
                    }
                } else {
                    const _0x5357fa = _0x29e78d['ZOUin']['split']('|');
                    let _0x42d8e0 = 0;
                    while (!![]) {
                        switch (_0x5357fa[_0x42d8e0++]) {
                        case '0':
                            countdownFooter['style']['color'] = _0x29e78d['KHsjT'];
                            continue;
                        case '1':
                            return;
                        case '2':
                            countdownFooter['textContent'] = 'Activation expired.';
                            continue;
                        case '3':
                            _0x29e78d['tNeGq'](checkActivation);
                            continue;
                        case '4':
                            clearInterval(countdownInterval);
                            continue;
                        }
                        break;
                    }
                }
            }
            countdownFooter['textContent'] = 'Activated. Time remaining: ' + _0x29e78d['VXDul'](formatTime, _0x394fb9), _0x394fb9 -= 1000;
        } else
            _0x2f1bdf['getElementById'](_0x29e78d['hHspC'])['style']['display'] = _0x29e78d['bdUCr'], _0x1d2337['getElementById'](_0x29e78d['uEUTe'])['style']['display'] = _0x29e78d['bnfVM'], _0x1a6328(_0x29e78d['ZCvYi']);
    };
    _0x59f9bd(), countdownInterval = _0x29e78d['AnibI'](setInterval, _0x59f9bd, 1000);
}
function handleActivation() {
    const _0x52de45 = a0_0x3c9c40, _0x51885f = {
            'MHZxc': 'status',
            'VwikQ': 'error',
            'ScztC': function (_0x4efc64, _0x55c30) {
                return _0x4efc64 <= _0x55c30;
            },
            'KrniM': '3|2|0|1|4',
            'Qcfji': '#ef4444',
            'vgeda': 'Activation expired.',
            'UYrUd': function (_0x4e980e, _0xa97efb) {
                return _0x4e980e(_0xa97efb);
            },
            'kpCQs': function (_0x1ef42a, _0x343ef2) {
                return _0x1ef42a(_0x343ef2);
            },
            'EKOjo': function (_0x2a82e8, _0x1437f8, _0x32231f) {
                return _0x2a82e8(_0x1437f8, _0x32231f);
            },
            'ZwdqU': function (_0x52ff99) {
                return _0x52ff99();
            },
            'WpbOb': function (_0x477da1, _0x5b3298) {
                return _0x477da1 !== _0x5b3298;
            },
            'vHTts': 'BIXTd',
            'vGKPw': function (_0x4bc6e5, _0x4e6618) {
                return _0x4bc6e5 === _0x4e6618;
            },
            'yMYxt': 'fQrQo',
            'NIVvR': 'Verification failed. Check your connection.',
            'UFXBP': function (_0x357685, _0x1292e4) {
                return _0x357685 === _0x1292e4;
            },
            'LwUtB': 'invalid',
            'eMBgL': 'Invalid activation key.',
            'oQJmU': 'activated',
            'ioDUR': 'Activation successful!',
            'FJIiJ': 'success',
            'XFNzj': 'activation-key',
            'xDNCj': 'Please enter a key.'
        }, _0x258971 = document['getElementById'](_0x51885f['XFNzj'])['value']['trim']();
    if (!_0x258971) {
        activationStatus['textContent'] = _0x51885f['xDNCj'], activationStatus['className'] = 'error';
        return;
    }
    activationStatus['textContent'] = 'Verifying...', activationStatus['className'] = '', chrome['runtime']['sendMessage']({
        'action': 'validate_activation_key',
        'key': _0x258971
    }, _0x16caa2 => {
        const _0x37f2ea = _0x52de45, _0xd69f53 = {
                'SmNiZ': function (_0x2ec6b6, _0x3ab5f1) {
                    const _0x3c7585 = a0_0x1f3f;
                    return _0x51885f['ScztC'](_0x2ec6b6, _0x3ab5f1);
                },
                'XaNrB': _0x51885f['KrniM'],
                'YuBPs': _0x51885f['Qcfji'],
                'XXoKl': function (_0x5da882) {
                    return _0x5da882();
                },
                'hJQSu': _0x51885f['vgeda'],
                'ocqsM': function (_0x28d027, _0x1f8cf4) {
                    return _0x51885f['UYrUd'](_0x28d027, _0x1f8cf4);
                },
                'qsmJl': function (_0x15dabc, _0x3fb1ff) {
                    const _0x2f0ddd = _0x37f2ea;
                    return _0x51885f['kpCQs'](_0x15dabc, _0x3fb1ff);
                },
                'ZDllC': function (_0x48996a, _0x20b0bc, _0x4f56ec) {
                    const _0x328762 = _0x37f2ea;
                    return _0x51885f['EKOjo'](_0x48996a, _0x20b0bc, _0x4f56ec);
                },
                'JATJm': function (_0x3e5855) {
                    const _0x496601 = _0x37f2ea;
                    return _0x51885f['ZwdqU'](_0x3e5855);
                }
            };
        if (_0x51885f['WpbOb'](_0x51885f['vHTts'], _0x51885f['vHTts'])) {
            if (_0x3273c2)
                pjifQC['qsmJl'](_0x4805ca, _0x40a25f);
            let _0x365e8b = _0x3e0f6a;
            const _0x2c5448 = () => {
                const _0x2f1fda = _0x37f2ea;
                if (pjifQC['SmNiZ'](_0x365e8b, 0)) {
                    const _0x1a57cb = pjifQC['XaNrB']['split']('|');
                    let _0x310c9f = 0;
                    while (!![]) {
                        switch (_0x1a57cb[_0x310c9f++]) {
                        case '0':
                            _0x156331['style']['color'] = pjifQC['YuBPs'];
                            continue;
                        case '1':
                            pjifQC['XXoKl'](_0x5ef088);
                            continue;
                        case '2':
                            _0x192281['textContent'] = pjifQC['hJQSu'];
                            continue;
                        case '3':
                            pjifQC['ocqsM'](_0x4b2054, _0x5e7118);
                            continue;
                        case '4':
                            return;
                        }
                        break;
                    }
                }
                _0x3e6d4b['textContent'] = 'Activated. Time remaining: ' + pjifQC['qsmJl'](_0x1960b5, _0x365e8b), _0x365e8b -= 1000;
            };
            pjifQC['XXoKl'](_0x2c5448), _0xde393b = pjifQC['ZDllC'](_0xdcebca, _0x2c5448, 1000);
        } else {
            if (!_0x16caa2 || _0x51885f['vGKPw'](_0x16caa2['status'], _0x51885f['VwikQ'])) {
                if (_0x51885f['WpbOb']('Hbted', _0x51885f['yMYxt']))
                    activationStatus['textContent'] = _0x16caa2['message'] || _0x51885f['NIVvR'], activationStatus['className'] = _0x51885f['VwikQ'];
                else {
                    const _0x229377 = _0x984ac4['getElementById'](_0x51885f['MHZxc']);
                    _0x229377['textContent'] = _0x2f7747, _0x229377['className'] = _0x13f902 ? _0x51885f['VwikQ'] : 'success';
                }
            } else {
                if (_0x51885f['UFXBP'](_0x16caa2['status'], _0x51885f['LwUtB']))
                    activationStatus['textContent'] = _0x51885f['eMBgL'], activationStatus['className'] = 'error';
                else
                    _0x51885f['UFXBP'](_0x16caa2['status'], _0x51885f['oQJmU']) && (activationStatus['textContent'] = _0x51885f['ioDUR'], activationStatus['className'] = _0x51885f['FJIiJ'], setTimeout(() => {
                        const _0x58e773 = _0x37f2ea;
                        _0xd69f53['JATJm'](checkActivation);
                    }, 1000));
            }
        }
    });
}
function handleDrainTime() {
    const _0x2c3eee = a0_0x3c9c40, _0x3f3afa = {
            'mJijW': function (_0x129303, _0x5bc9b1) {
                return _0x129303(_0x5bc9b1);
            },
            'mDJtp': 'file-upload',
            'IGhGo': 'report-btn',
            'RWfjL': 'pqdnd',
            'wDgFW': function (_0x2c33a1, _0x1870de) {
                return _0x2c33a1(_0x1870de);
            },
            'lHeYc': 'Activation forced to expire.',
            'MZLRp': 'activation-key',
            'yrjwk': 'drain_time'
        };
    chrome['runtime']['sendMessage']({ 'action': _0x3f3afa['yrjwk'] }, _0x257f9d => {
        const _0x1774a1 = _0x2c3eee, _0x4cd91c = {
                'eHzCD': '8|4|1|7|9|2|6|0|5|3',
                'YyfBm': function (_0x5c5221, _0x464318) {
                    const _0x332919 = _0x1774a1;
                    return _0x3f3afa['mJijW'](_0x5c5221, _0x464318);
                },
                'qJCFJ': 'start-btn',
                'EAYas': 'preview-container',
                'jJiES': _0x3f3afa['mDJtp'],
                'WUnKz': 'action-buttons',
                'SOsLE': 'none',
                'MTzOk': _0x3f3afa['IGhGo']
            };
        if (_0x3f3afa['RWfjL'] !== 'NjLIG') {
            if (countdownInterval)
                _0x3f3afa['wDgFW'](clearInterval, countdownInterval);
            activationView['style']['display'] = 'block', mainAppView['style']['display'] = 'none', activationStatus['textContent'] = _0x3f3afa['lHeYc'], activationStatus['className'] = 'error', document['getElementById'](_0x3f3afa['MZLRp'])['value'] = '';
        } else
            _0x2830d4['runtime']['sendMessage']({ 'action': 'stop_sending' }, _0x4cee93 => {
                const _0x3b942d = _0x1774a1, _0x4c3615 = _0x4cd91c['eHzCD']['split']('|');
                let _0x3a9eea = 0;
                while (!![]) {
                    switch (_0x4c3615[_0x3a9eea++]) {
                    case '0':
                        _0x4cd91c['YyfBm'](_0x2e60ba, null);
                        continue;
                    case '1':
                        _0x2b08ad['getElementById'](_0x4cd91c['qJCFJ'])['disabled'] = ![];
                        continue;
                    case '2':
                        _0x5ae0a4 = [];
                        continue;
                    case '3':
                        _0x436407('Sending stopped and reset.');
                        continue;
                    case '4':
                        _0xe2a5e3['getElementById'](_0x4cd91c['qJCFJ'])['style']['display'] = 'block';
                        continue;
                    case '5':
                        _0x68a4f4['getElementById'](_0x4cd91c['EAYas'])['style']['display'] = 'none';
                        continue;
                    case '6':
                        _0x5d0ae2['getElementById'](_0x4cd91c['jJiES'])['value'] = '';
                        continue;
                    case '7':
                        _0x2b521f['getElementById']('file-upload')['disabled'] = ![];
                        continue;
                    case '8':
                        _0x321493['getElementById'](_0x4cd91c['WUnKz'])['style']['display'] = _0x4cd91c['SOsLE'];
                        continue;
                    case '9':
                        _0x96c576['getElementById'](_0x4cd91c['MTzOk'])['style']['display'] = _0x4cd91c['SOsLE'];
                        continue;
                    }
                    break;
                }
            });
    });
}
function checkActivation() {
    const _0x8eca52 = a0_0x3c9c40, _0xfbfaa4 = {
            'GFoSo': '8|3|4|6|9|1|5|0|7|2',
            'KjshG': function (_0x57f73f, _0x1d927d) {
                return _0x57f73f(_0x1d927d);
            },
            'lqwCC': function (_0x1f1739, _0xe63c48) {
                return _0x1f1739(_0xe63c48);
            },
            'CSuva': 'Sending stopped and reset.',
            'Cxuqh': 'start-btn',
            'MkPIv': 'file-upload',
            'FYbZy': 'none',
            'raWrR': 'report-btn',
            'UlyiX': '0.5',
            'KAQLU': 'not-allowed',
            'BMXYg': 'Error parsing file. Please ensure it\'s a valid CSV/Excel file.',
            'dSqaH': function (_0x271508, _0x255d32) {
                return _0x271508 !== _0x255d32;
            },
            'CTsht': 'cLrLU',
            'SNwul': function (_0x268ef5, _0x11810c) {
                return _0x268ef5 === _0x11810c;
            },
            'vNqGK': 'jgmdp',
            'DKqFz': 'block',
            'zycUL': 'Master License Active.',
            'NQvyH': function (_0x4d02f2, _0x3cb25b) {
                return _0x4d02f2 === _0x3cb25b;
            },
            'qJrpc': 'vuDyr',
            'JwpZY': 'check_activation_status'
        };
    chrome['runtime']['sendMessage']({ 'action': _0xfbfaa4['JwpZY'] }, _0xbe8ec6 => {
        const _0x49bfe5 = _0x8eca52, _0x39511c = {
                'XohcV': function (_0x566ce4, _0xf3e703, _0x4e89b9) {
                    return _0x566ce4(_0xf3e703, _0x4e89b9);
                },
                'ZhxVs': _0xfbfaa4['BMXYg']
            };
        if (!_0xbe8ec6 || !_0xbe8ec6['isActive']) {
            if (_0xfbfaa4['dSqaH'](_0xfbfaa4['CTsht'], _0xfbfaa4['CTsht'])) {
                const _0x111f0c = _0xfbfaa4['GFoSo']['split']('|');
                let _0x563504 = 0;
                while (!![]) {
                    switch (_0x111f0c[_0x563504++]) {
                    case '0':
                        _0xfbfaa4['KjshG'](_0x5e009a, null);
                        continue;
                    case '1':
                        _0x25ac43 = [];
                        continue;
                    case '2':
                        _0xfbfaa4['lqwCC'](_0xe4506d, _0xfbfaa4['CSuva']);
                        continue;
                    case '3':
                        _0x2184a6['getElementById'](_0xfbfaa4['Cxuqh'])['style']['display'] = 'block';
                        continue;
                    case '4':
                        _0x1f72dc['getElementById'](_0xfbfaa4['Cxuqh'])['disabled'] = ![];
                        continue;
                    case '5':
                        _0x44b45d['getElementById'](_0xfbfaa4['MkPIv'])['value'] = '';
                        continue;
                    case '6':
                        _0x23efc6['getElementById'](_0xfbfaa4['MkPIv'])['disabled'] = ![];
                        continue;
                    case '7':
                        _0xffdf25['getElementById']('preview-container')['style']['display'] = _0xfbfaa4['FYbZy'];
                        continue;
                    case '8':
                        _0x219d84['getElementById']('action-buttons')['style']['display'] = _0xfbfaa4['FYbZy'];
                        continue;
                    case '9':
                        _0x3b183a['getElementById'](_0xfbfaa4['raWrR'])['style']['display'] = _0xfbfaa4['FYbZy'];
                        continue;
                    }
                    break;
                }
            } else
                activationView['style']['display'] = 'block', mainAppView['style']['display'] = _0xfbfaa4['FYbZy'];
        } else {
            if (_0xfbfaa4['SNwul'](_0xfbfaa4['vNqGK'], _0xfbfaa4['vNqGK'])) {
                activationView['style']['display'] = _0xfbfaa4['FYbZy'], mainAppView['style']['display'] = _0xfbfaa4['DKqFz'];
                if (_0xbe8ec6['isMaster'])
                    countdownFooter['textContent'] = _0xfbfaa4['zycUL'];
                else
                    _0xbe8ec6['remainingTime'] && (_0xfbfaa4['NQvyH'](_0xfbfaa4['qJrpc'], 'juYsq') ? (_0x4648eb['disabled'] = !![], _0x12105e['style']['opacity'] = VVcKxQ['UlyiX'], _0x197608['style']['cursor'] = VVcKxQ['KAQLU']) : _0xfbfaa4['lqwCC'](startCountdown, _0xbe8ec6['remainingTime']));
            } else
                _0x39511c['XohcV'](_0x44170e, _0x39511c['ZhxVs'], !![]), _0x5d186b['error'](_0xe3e674);
        }
    });
}
function a0_0x1f3f(_0x9f27c, _0x50a543) {
    _0x9f27c = _0x9f27c - 117;
    const _0x48a652 = a0_0x48a6();
    let _0x1f3f39 = _0x48a652[_0x9f27c];
    if (a0_0x1f3f['epfErU'] === undefined) {
        var _0x2eb967 = function (_0x21902e) {
            const _0x118716 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
            let _0x5b465b = '', _0x1dfda0 = '';
            for (let _0x3067fd = 0, _0x1ddffa, _0x1fe860, _0x342bd9 = 0; _0x1fe860 = _0x21902e['charAt'](_0x342bd9++); ~_0x1fe860 && (_0x1ddffa = _0x3067fd % 4 ? _0x1ddffa * 64 + _0x1fe860 : _0x1fe860, _0x3067fd++ % 4) ? _0x5b465b += String['fromCharCode'](255 & _0x1ddffa >> (-2 * _0x3067fd & 6)) : 0) {
                _0x1fe860 = _0x118716['indexOf'](_0x1fe860);
            }
            for (let _0x3db9b0 = 0, _0x29456b = _0x5b465b['length']; _0x3db9b0 < _0x29456b; _0x3db9b0++) {
                _0x1dfda0 += '%' + ('00' + _0x5b465b['charCodeAt'](_0x3db9b0)['toString'](16))['slice'](-2);
            }
            return decodeURIComponent(_0x1dfda0);
        };
        a0_0x1f3f['WITUeQ'] = _0x2eb967, a0_0x1f3f['CMMVvG'] = {}, a0_0x1f3f['epfErU'] = !![];
    }
    const _0x3030f7 = _0x48a652[0];
    a0_0x1f3f['DEJDwq'] !== _0x3030f7 && (a0_0x1f3f['CMMVvG'] = {}, a0_0x1f3f['DEJDwq'] = _0x3030f7);
    const _0x199b3c = a0_0x1f3f['CMMVvG'][_0x9f27c];
    return _0x199b3c === undefined ? (_0x1f3f39 = a0_0x1f3f['WITUeQ'](_0x1f3f39), a0_0x1f3f['CMMVvG'][_0x9f27c] = _0x1f3f39) : _0x1f3f39 = _0x199b3c, _0x1f3f39;
}
function autoResizeTextarea() {
    const _0x136754 = a0_0x3c9c40, _0x33ea69 = {
            'HQbwy': function (_0x170b1d, _0x4b2817) {
                return _0x170b1d(_0x4b2817);
            },
            'IfdzF': function (_0x5edf01, _0x97b491) {
                return _0x5edf01 > _0x97b491;
            },
            'yadbV': function (_0xcab791, _0x472c8a) {
                return _0xcab791 === _0x472c8a;
            },
            'PeuTV': 'GNcdK',
            'HCSEm': function (_0x2c549f, _0x4d9204) {
                return _0x2c549f + _0x4d9204;
            },
            'SGesn': function (_0x1b40ce, _0x23edfb) {
                return _0x1b40ce + _0x23edfb;
            },
            'rkFFA': 'auto',
            'gROcp': function (_0x39d25b, _0x5cd4b2, _0x1cdd07) {
                return _0x39d25b(_0x5cd4b2, _0x1cdd07);
            }
        };
    templateInput['style']['height'] = _0x33ea69['rkFFA'], _0x33ea69['gROcp'](setTimeout, () => {
        const _0x4541a8 = _0x136754, _0x46bdb2 = {
                'jKxwq': function (_0x14a769, _0x2d2a37) {
                    const _0x5cd0f0 = a0_0x1f3f;
                    return _0x33ea69['HQbwy'](_0x14a769, _0x2d2a37);
                }
            };
        if (_0x33ea69['IfdzF'](templateInput['scrollHeight'], 20)) {
            if (_0x33ea69['yadbV'](_0x33ea69['PeuTV'], _0x33ea69['PeuTV']))
                templateInput['style']['height'] = _0x33ea69['HCSEm'](_0x33ea69['SGesn'](templateInput['scrollHeight'], 2), 'px');
            else {
                _0x46bdb2['jKxwq'](_0x5a02d5, 'Cannot save an empty template.');
                return;
            }
        }
    }, 10);
}
function loadCampaigns() {
    const _0x236ac4 = a0_0x3c9c40, _0x39a44b = {
            'hTmNp': function (_0x13e25e, _0x2cece4) {
                return _0x13e25e + _0x2cece4;
            },
            'XmNCC': function (_0x18c95a, _0x3eb0e1) {
                return _0x18c95a === _0x3eb0e1;
            },
            'cWBGP': 'LCCWC',
            'VqdRp': 'option',
            'uKGTD': 'siloCampaigns'
        };
    chrome['storage']['local']['get']([_0x39a44b['uKGTD']], _0x1aefc7 => {
        const _0x1c162a = _0x236ac4, _0x562560 = {
                'QtTWF': function (_0x3b8f86, _0x5b43d3) {
                    const _0x28c3d9 = a0_0x1f3f;
                    return _0x39a44b['hTmNp'](_0x3b8f86, _0x5b43d3);
                },
                'Fxfqx': function (_0x4eb08e, _0x5da34a) {
                    return _0x4eb08e + _0x5da34a;
                }
            }, _0x1cac25 = _0x1aefc7['siloCampaigns'] || {};
        campaignSelect['innerHTML'] = '<option value="default">-- Select a Campaign Template --</option>';
        for (const _0x5435ea in _0x1cac25) {
            if (_0x39a44b['XmNCC']('RcgJf', _0x39a44b['cWBGP']))
                _0x59b551['style']['height'] = teofri['QtTWF'](teofri['Fxfqx'](_0x3895dc['scrollHeight'], 2), 'px');
            else {
                const _0x3f212d = document['createElement'](_0x39a44b['VqdRp']);
                _0x3f212d['value'] = _0x5435ea, _0x3f212d['textContent'] = _0x5435ea, campaignSelect['appendChild'](_0x3f212d);
            }
        }
    });
}
saveCampaignBtn['addEventListener']('click', () => {
    const _0x5d72d4 = a0_0x3c9c40, _0x5f51ae = {
            'LDxuj': 'string',
            'cbpip': function (_0x3a3eea, _0x27f5a0) {
                return _0x3a3eea(_0x27f5a0);
            },
            'lBSAm': 'Error parsing CSV file.',
            'VcmPj': function (_0x421fa9) {
                return _0x421fa9();
            },
            'OcoWr': '<option value="default">-- Select a Campaign Template --</option>',
            'VcxIf': function (_0x2fa2ef, _0x9ef787) {
                return _0x2fa2ef !== _0x9ef787;
            },
            'fKWpa': 'ViEsh',
            'EDIWG': 'Cannot save an empty template.',
            'XXnfO': 'pyikD',
            'ePfyB': 'siloCampaigns'
        }, _0x426849 = templateInput['value']['trim']();
    if (!_0x426849) {
        _0x5f51ae['cbpip'](alert, _0x5f51ae['EDIWG']);
        return;
    }
    const _0x391994 = _0x5f51ae['cbpip'](prompt, 'Enter a name for this campaign template:');
    _0x391994 && (_0x5f51ae['VcxIf'](_0x5f51ae['XXnfO'], _0x5f51ae['XXnfO']) ? (_0x25f4ab['readAsText'](_0x284cf4), _0x1d3c79['onload'] = function (_0x45b145) {
        const _0x1028c6 = _0x5d72d4, _0x2b1394 = _0x45b145['target']['result'];
        try {
            const _0xf060c8 = _0x44fbab['read'](_0x2b1394, { 'type': _0x5f51ae['LDxuj'] }), _0x58b216 = _0xf060c8['SheetNames'][0], _0x208aaa = _0xf060c8['Sheets'][_0x58b216], _0x48c6a7 = _0x430328['utils']['sheet_to_json'](_0x208aaa, { 'header': 1 });
            _0x5f51ae['cbpip'](_0x6e96c7, _0x48c6a7);
        } catch (_0x44c790) {
            _0x15031a(_0x5f51ae['lBSAm'], !![]);
        }
    }) : chrome['storage']['local']['get']([_0x5f51ae['ePfyB']], _0x1220be => {
        const _0x5ddc51 = _0x5d72d4, _0x44dfaf = {
                'QOMUR': _0x5f51ae['OcoWr'],
                'sSvuy': 'option'
            };
        if (_0x5f51ae['VcxIf'](_0x5f51ae['fKWpa'], 'ViEsh')) {
            const _0x2f1c45 = _0x1a9a91['siloCampaigns'] || {};
            _0xd34096['innerHTML'] = LlEmeL['QOMUR'];
            for (const _0x3a1630 in _0x2f1c45) {
                const _0x5ebe33 = _0x1d2b82['createElement'](LlEmeL['sSvuy']);
                _0x5ebe33['value'] = _0x3a1630, _0x5ebe33['textContent'] = _0x3a1630, _0x4e94a4['appendChild'](_0x5ebe33);
            }
        } else {
            const _0x59660a = _0x1220be['siloCampaigns'] || {};
            _0x59660a[_0x391994] = _0x426849, chrome['storage']['local']['set']({ 'siloCampaigns': _0x59660a }, () => {
                const _0xdac7de = _0x5ddc51;
                _0x5f51ae['VcmPj'](loadCampaigns), campaignSelect['value'] = _0x391994;
            });
        }
    }));
}), campaignSelect['addEventListener']('change', _0x490ba1 => {
    const _0x257631 = a0_0x3c9c40, _0x52d115 = {
            'ncsMS': function (_0x50eb2e, _0x578a1d) {
                return _0x50eb2e(_0x578a1d);
            },
            'vpGOA': function (_0x4b0d24, _0x2152b6) {
                return _0x4b0d24 !== _0x2152b6;
            },
            'xfOww': 'nBqRE',
            'APwdM': 'jsIOc',
            'mdZkv': 'yKQsM',
            'hahpd': 'string',
            'NsOaV': 'none',
            'EyBTs': 'resume-btn',
            'IUfQO': 'block',
            'VsyLg': function (_0xd14e6e, _0x365e66) {
                return _0xd14e6e(_0x365e66);
            },
            'buSGT': 'Sending paused.',
            'obsbj': 'error',
            'wBDiv': function (_0x207141, _0x5e6386) {
                return _0x207141 === _0x5e6386;
            },
            'ESPSG': 'tNwXD',
            'DsuYZ': 'binary',
            'fvqzL': function (_0x2fecc5) {
                return _0x2fecc5();
            },
            'JknTB': function (_0x66a740) {
                return _0x66a740();
            },
            'Hdvdy': function (_0x1a1810, _0x40bffd) {
                return _0x1a1810 > _0x40bffd;
            },
            'ltYMo': 'file-upload',
            'CyAia': function (_0xb1c3f1, _0x26ed47) {
                return _0xb1c3f1 > _0x26ed47;
            },
            'sOQdj': '.csv',
            'FQvHZ': 'obIoZ',
            'FPZnm': function (_0xe5dac6, _0x2ecd34) {
                return _0xe5dac6 === _0x2ecd34;
            },
            'GtLXf': 'ZxVHn',
            'WSLeR': function (_0x58c347, _0x4edd28) {
                return _0x58c347 !== _0x4edd28;
            },
            'TsMjL': 'default'
        }, _0x53380d = _0x490ba1['target']['value'];
    _0x52d115['WSLeR'](_0x53380d, _0x52d115['TsMjL']) && chrome['storage']['local']['get'](['siloCampaigns'], _0xba5dd7 => {
        const _0x5421ff = _0x257631, _0x345661 = {
                'WuPtd': 'pause-btn',
                'KrCGy': _0x52d115['NsOaV'],
                'gQEtJ': _0x52d115['EyBTs'],
                'twhmL': _0x52d115['IUfQO'],
                'NOeJj': function (_0x28e634, _0x54bc0) {
                    const _0x286d46 = _0x5421ff;
                    return _0x52d115['VsyLg'](_0x28e634, _0x54bc0);
                },
                'hxBoU': _0x52d115['buSGT'],
                'JeJkD': 'Invalid activation key.',
                'VWUyd': _0x52d115['obsbj'],
                'FrmLV': function (_0xcccde1, _0x484188) {
                    const _0x2ea4ee = _0x5421ff;
                    return _0x52d115['wBDiv'](_0xcccde1, _0x484188);
                },
                'EMfeB': 'TRMaz',
                'pDVKD': function (_0x53799f, _0x4cf582) {
                    return _0x53799f !== _0x4cf582;
                },
                'TgNdi': _0x52d115['ESPSG'],
                'DyTuK': 'tjcwN',
                'ixnsd': _0x52d115['DsuYZ'],
                'BzaMu': function (_0x480e22, _0x53604b) {
                    return _0x480e22(_0x53604b);
                },
                'gpjUX': function (_0x2a78e4) {
                    return _0x52d115['fvqzL'](_0x2a78e4);
                }
            }, _0x57efd0 = _0xba5dd7['siloCampaigns'] || {};
        if (_0x57efd0[_0x53380d]) {
            templateInput['value'] = _0x57efd0[_0x53380d], _0x52d115['JknTB'](autoResizeTextarea), chrome['storage']['local']['set']({ 'siloTemplate': _0x57efd0[_0x53380d] });
            if (_0x52d115['Hdvdy'](parsedData['length'], 0)) {
                const _0x20e88b = document['getElementById'](_0x52d115['ltYMo']);
                if (_0x52d115['CyAia'](_0x20e88b['files']['length'], 0)) {
                    const _0x56ca81 = _0x20e88b['files'][0], _0x2d1a2c = new FileReader();
                    if (_0x56ca81['name']['endsWith'](_0x52d115['sOQdj']))
                        _0x52d115['FQvHZ'] === 'tFuKx' ? yJMPHT['ncsMS'](_0x38a62f, _0x512008['remainingTime']) : (_0x2d1a2c['readAsText'](_0x56ca81), _0x2d1a2c['onload'] = function (_0x55f10e) {
                            const _0x6718e4 = _0x5421ff;
                            if (_0x52d115['vpGOA'](_0x52d115['xfOww'], 'nBqRE'))
                                _0x38df3d['value'] = '', _0x30fb1a['storage']['local']['set']({ 'siloTemplate': '' });
                            else
                                try {
                                    if (_0x52d115['APwdM'] === _0x52d115['mdZkv'])
                                        _0x4cc128['getElementById'](_0x345661['WuPtd'])['style']['display'] = _0x345661['KrCGy'], _0x52a798['getElementById'](_0x345661['gQEtJ'])['style']['display'] = _0x345661['twhmL'], _0x345661['NOeJj'](_0xfe32af, _0x345661['hxBoU']);
                                    else {
                                        const _0x51ac91 = XLSX['read'](_0x55f10e['target']['result'], { 'type': _0x52d115['hahpd'] }), _0x12e4e2 = _0x51ac91['SheetNames'][0], _0x4221ef = _0x51ac91['Sheets'][_0x12e4e2], _0x127f12 = XLSX['utils']['sheet_to_json'](_0x4221ef, { 'header': 1 });
                                        _0x52d115['ncsMS'](processData, _0x127f12);
                                    }
                                } catch (_0x5aee4b) {
                                }
                        });
                    else {
                        if (_0x52d115['FPZnm'](_0x52d115['GtLXf'], _0x52d115['GtLXf']))
                            _0x2d1a2c['readAsBinaryString'](_0x56ca81), _0x2d1a2c['onload'] = function (_0x5c63a0) {
                                const _0x107f3e = _0x5421ff, _0x240720 = {
                                        'dkOlD': _0x345661['JeJkD'],
                                        'rzlHc': _0x345661['VWUyd'],
                                        'TukFs': function (_0x1462d0, _0x572a82) {
                                            return _0x1462d0(_0x572a82);
                                        }
                                    };
                                if (_0x345661['FrmLV']('TRMaz', _0x345661['EMfeB']))
                                    try {
                                        if (_0x345661['pDVKD'](_0x345661['TgNdi'], _0x345661['DyTuK'])) {
                                            const _0x1cd95d = XLSX['read'](_0x5c63a0['target']['result'], { 'type': _0x345661['ixnsd'] }), _0x45523c = _0x1cd95d['SheetNames'][0], _0x5db9a5 = _0x1cd95d['Sheets'][_0x45523c], _0x49edbb = XLSX['utils']['sheet_to_json'](_0x5db9a5, { 'header': 1 });
                                            _0x345661['BzaMu'](processData, _0x49edbb);
                                        } else
                                            _0x291e10['textContent'] = MkorZk['dkOlD'], _0x438a6f['className'] = MkorZk['rzlHc'];
                                    } catch (_0x149e06) {
                                    }
                                else {
                                    const _0x206baf = _0x247712['read'](_0x2c6615, { 'type': 'string' }), _0x5a1288 = _0x206baf['SheetNames'][0], _0x2a3703 = _0x206baf['Sheets'][_0x5a1288], _0x20f68d = _0xe36cc0['utils']['sheet_to_json'](_0x2a3703, { 'header': 1 });
                                    _0x240720['TukFs'](_0xa90b32, _0x20f68d);
                                }
                            };
                        else {
                            const _0x173f03 = _0x1e257d['siloCampaigns'] || {};
                            _0x173f03[_0x333051] = _0x1860c0, _0xdbec43['storage']['local']['set']({ 'siloCampaigns': _0x173f03 }, () => {
                                const _0x168382 = _0x5421ff;
                                MSrqJU['gpjUX'](_0x49e655), _0x3b657a['value'] = _0xd191db;
                            });
                        }
                    }
                }
            }
        }
    });
}), templateInput['addEventListener']('input', () => {
    const _0x5c9d00 = a0_0x3c9c40, _0x2e4e82 = {
            'agdkk': function (_0x4db3d1) {
                return _0x4db3d1();
            }
        };
    _0x2e4e82['agdkk'](autoResizeTextarea), chrome['storage']['local']['set']({ 'siloTemplate': templateInput['value'] }), campaignSelect['value'] = 'default';
    if (parsedData['length'] > 0) {
    }
});
function downloadSampleCSV(_0x2f7a41) {
    const _0x355535 = a0_0x3c9c40, _0x116e16 = {
            'OtzBy': 'data:text/csv;charset=utf-8,CN Number,COD Amount,Consignee Name,Phone Number\n123456789,1500,Ali Khan,923001234567\n987654321,2500,Usman Ali,923007654321',
            'Eqoyj': 'download',
            'EguYd': 'silo_sample.csv'
        };
    _0x2f7a41['preventDefault']();
    const _0x97d78b = _0x116e16['OtzBy'], _0x50a9fe = encodeURI(_0x97d78b), _0x33ba9a = document['createElement']('a');
    _0x33ba9a['setAttribute']('href', _0x50a9fe), _0x33ba9a['setAttribute'](_0x116e16['Eqoyj'], _0x116e16['EguYd']), document['body']['appendChild'](_0x33ba9a), _0x33ba9a['click'](), document['body']['removeChild'](_0x33ba9a);
}
function updateStatus(_0x14acd6, _0x5d6991 = ![]) {
    const _0x4734ff = a0_0x3c9c40, _0x2bfa38 = {
            'QqqJz': 'status',
            'cbcjJ': 'error'
        }, _0x391aef = document['getElementById'](_0x2bfa38['QqqJz']);
    _0x391aef['textContent'] = _0x14acd6, _0x391aef['className'] = _0x5d6991 ? _0x2bfa38['cbcjJ'] : 'success';
}
function renderPreview() {
    const _0xe03895 = a0_0x3c9c40, _0x21a539 = {
            'WythS': function (_0x4a2949, _0x49511d) {
                return _0x4a2949 < _0x49511d;
            },
            'SgYqW': 'preview-count',
            'gxBvT': 'preview-container',
            'srNQX': 'block'
        }, _0x1ead65 = document['getElementById']('preview-body');
    _0x1ead65['innerHTML'] = '';
    const _0x2143d9 = Math['min'](parsedData['length'], 100);
    for (let _0x2104b6 = 0; _0x21a539['WythS'](_0x2104b6, _0x2143d9); _0x2104b6++) {
        const _0x4012d3 = document['createElement']('tr'), _0x37859d = document['createElement']('td');
        _0x37859d['textContent'] = parsedData[_0x2104b6]['phone'];
        const _0xf5362e = document['createElement']('td');
        _0xf5362e['textContent'] = parsedData[_0x2104b6]['message'], _0x4012d3['appendChild'](_0x37859d), _0x4012d3['appendChild'](_0xf5362e), _0x1ead65['appendChild'](_0x4012d3);
    }
    document['getElementById'](_0x21a539['SgYqW'])['textContent'] = 'Total valid rows: ' + parsedData['length'], document['getElementById'](_0x21a539['gxBvT'])['style']['display'] = _0x21a539['srNQX'];
}
function startSending() {
    const _0x5c3b1e = a0_0x3c9c40, _0x4ac903 = {
            'CsDbJ': function (_0x50f2d, _0x56bf6f) {
                return _0x50f2d === _0x56bf6f;
            },
            'MPhla': 'SeaWG',
            'jxsyQ': function (_0x2b3e06, _0x5173c4, _0x282267) {
                return _0x2b3e06(_0x5173c4, _0x282267);
            },
            'IblhE': 'Error: Could not connect to background process.',
            'yQqSC': 'started',
            'HPpig': '1|5|4|2|0|3',
            'vhzzq': function (_0x480a21, _0x365f74) {
                return _0x480a21(_0x365f74);
            },
            'yvKoi': 'Sending in progress... Please keep WhatsApp Web open.',
            'fxRgl': 'start-btn',
            'Sldgg': 'resume-btn',
            'NzwYF': 'none',
            'fVuot': 'pause-btn',
            'eBFmF': 'action-buttons',
            'xxcJc': 'flex',
            'fPCgQ': function (_0x204afc, _0x5704cf) {
                return _0x204afc === _0x5704cf;
            },
            'vcOtB': 'iXhBB',
            'WLfCS': function (_0x2ba831, _0x1c1c0f, _0x1648b5) {
                return _0x2ba831(_0x1c1c0f, _0x1648b5);
            },
            'ldelX': 'Error: ',
            'OebhG': function (_0x533fee, _0x418d78) {
                return _0x533fee === _0x418d78;
            },
            'NpAUT': 'file-upload',
            'BkaSf': 'Starting...',
            'ZTMLp': 'delay-min',
            'kQfPo': 'delay-max',
            'lvwXl': 'start_sending'
        };
    if (_0x4ac903['OebhG'](parsedData['length'], 0))
        return;
    document['getElementById'](_0x4ac903['fxRgl'])['disabled'] = !![], document['getElementById'](_0x4ac903['NpAUT'])['disabled'] = !![], _0x4ac903['jxsyQ'](updateStatus, _0x4ac903['BkaSf'], ![]);
    const _0x77f359 = parseInt(document['getElementById'](_0x4ac903['ZTMLp'])['value']) || 3, _0x2d96a8 = parseInt(document['getElementById'](_0x4ac903['kQfPo'])['value']) || 5;
    chrome['runtime']['sendMessage']({
        'action': _0x4ac903['lvwXl'],
        'data': parsedData,
        'delayMin': _0x77f359,
        'delayMax': _0x2d96a8,
        'attachment': null
    }, _0x15a8ca => {
        const _0x276222 = _0x5c3b1e;
        if (chrome['runtime']['lastError']) {
            if (_0x4ac903['CsDbJ']('SeaWG', _0x4ac903['MPhla'])) {
                _0x4ac903['jxsyQ'](updateStatus, _0x4ac903['IblhE'], !![]), console['error'](chrome['runtime']['lastError']);
                return;
            } else
                _0xa3188f(), _0x5989c7['value'] = _0x3133ff;
        }
        if (_0x15a8ca && _0x15a8ca['status'] === _0x4ac903['yQqSC']) {
            const _0x56ce6c = _0x4ac903['HPpig']['split']('|');
            let _0x45ba89 = 0;
            while (!![]) {
                switch (_0x56ce6c[_0x45ba89++]) {
                case '0':
                    _0x4ac903['vhzzq'](updateStatus, _0x4ac903['yvKoi']);
                    continue;
                case '1':
                    document['getElementById'](_0x4ac903['fxRgl'])['style']['display'] = 'none';
                    continue;
                case '2':
                    document['getElementById'](_0x4ac903['Sldgg'])['style']['display'] = _0x4ac903['NzwYF'];
                    continue;
                case '3':
                    checkProgress();
                    continue;
                case '4':
                    document['getElementById'](_0x4ac903['fVuot'])['style']['display'] = 'block';
                    continue;
                case '5':
                    document['getElementById'](_0x4ac903['eBFmF'])['style']['display'] = _0x4ac903['xxcJc'];
                    continue;
                }
                break;
            }
        } else
            _0x15a8ca && _0x15a8ca['error'] && (_0x4ac903['fPCgQ'](_0x4ac903['vcOtB'], _0x4ac903['vcOtB']) ? (_0x4ac903['WLfCS'](updateStatus, _0x4ac903['ldelX'] + _0x15a8ca['error'], !![]), document['getElementById'](_0x4ac903['fxRgl'])['disabled'] = ![], document['getElementById']('file-upload')['disabled'] = ![]) : _0x27e2e4['readAsBinaryString'](_0x2c9aef));
    });
}
function stopSending() {
    const _0x4c7b74 = a0_0x3c9c40, _0x1363af = {
            'vftVs': '3|7|2|6|0|1|4|5|8|9',
            'VQdhN': 'report-btn',
            'cKRTu': 'none',
            'KvTLW': 'start-btn',
            'RdFLO': 'file-upload',
            'XAuNE': function (_0x33beb3, _0x5c926d) {
                return _0x33beb3(_0x5c926d);
            },
            'XQugq': 'block',
            'ilVxS': 'preview-container',
            'eWOMO': 'Sending stopped and reset.',
            'sAmOJ': 'stop_sending'
        };
    chrome['runtime']['sendMessage']({ 'action': _0x1363af['sAmOJ'] }, _0x379082 => {
        const _0x4646c4 = _0x4c7b74, _0x252a8a = _0x1363af['vftVs']['split']('|');
        let _0xe5e1eb = 0;
        while (!![]) {
            switch (_0x252a8a[_0xe5e1eb++]) {
            case '0':
                document['getElementById'](_0x1363af['VQdhN'])['style']['display'] = _0x1363af['cKRTu'];
                continue;
            case '1':
                parsedData = [];
                continue;
            case '2':
                document['getElementById'](_0x1363af['KvTLW'])['disabled'] = ![];
                continue;
            case '3':
                document['getElementById']('action-buttons')['style']['display'] = _0x1363af['cKRTu'];
                continue;
            case '4':
                document['getElementById'](_0x1363af['RdFLO'])['value'] = '';
                continue;
            case '5':
                _0x1363af['XAuNE'](updateFileNameDisplay, null);
                continue;
            case '6':
                document['getElementById']('file-upload')['disabled'] = ![];
                continue;
            case '7':
                document['getElementById'](_0x1363af['KvTLW'])['style']['display'] = _0x1363af['XQugq'];
                continue;
            case '8':
                document['getElementById'](_0x1363af['ilVxS'])['style']['display'] = _0x1363af['cKRTu'];
                continue;
            case '9':
                _0x1363af['XAuNE'](updateStatus, _0x1363af['eWOMO']);
                continue;
            }
            break;
        }
    });
}
function pauseSending() {
    const _0x4cf03b = a0_0x3c9c40, _0x48a495 = {
            'eoBEm': 'binary',
            'qTyJO': function (_0x478c10, _0x26cdbc) {
                return _0x478c10(_0x26cdbc);
            },
            'pPxEs': 'aUQKw',
            'pMyKi': 'pause-btn',
            'oydgX': 'none',
            'gwOum': 'resume-btn',
            'dBqft': 'block',
            'HruBG': function (_0x1911ab, _0x42fc94) {
                return _0x1911ab(_0x42fc94);
            },
            'MuTiZ': 'Sending paused.',
            'tRnOT': 'pause_sending'
        };
    chrome['runtime']['sendMessage']({ 'action': _0x48a495['tRnOT'] }, _0x310099 => {
        const _0x36691b = _0x4cf03b, _0x5390bf = {
                'eykLu': _0x48a495['eoBEm'],
                'JSdbc': function (_0x51801a, _0x5d183f) {
                    const _0x6f1571 = _0x36691b;
                    return _0x48a495['qTyJO'](_0x51801a, _0x5d183f);
                }
            };
        if (_0x48a495['pPxEs'] === _0x48a495['pPxEs'])
            document['getElementById'](_0x48a495['pMyKi'])['style']['display'] = _0x48a495['oydgX'], document['getElementById'](_0x48a495['gwOum'])['style']['display'] = _0x48a495['dBqft'], _0x48a495['HruBG'](updateStatus, _0x48a495['MuTiZ']);
        else {
            const _0x2d621c = _0x45f11e['read'](_0x333dd5['target']['result'], { 'type': VXUAPi['eykLu'] }), _0x3eb2da = _0x2d621c['SheetNames'][0], _0x3ed526 = _0x2d621c['Sheets'][_0x3eb2da], _0x48dec2 = _0x4bd6fc['utils']['sheet_to_json'](_0x3ed526, { 'header': 1 });
            VXUAPi['JSdbc'](_0x254368, _0x48dec2);
        }
    });
}
function resumeSending() {
    const _0x3e3441 = a0_0x3c9c40, _0x3b7a0d = {
            'rZIyA': function (_0xe3d4bf, _0x2b99c7) {
                return _0xe3d4bf(_0x2b99c7);
            },
            'wukxx': 'Sending resumed... Please keep WhatsApp Web open.',
            'ablxb': 'resume_sending'
        };
    chrome['runtime']['sendMessage']({ 'action': _0x3b7a0d['ablxb'] }, _0x5582c9 => {
        const _0x5db592 = _0x3e3441;
        document['getElementById']('resume-btn')['style']['display'] = 'none', document['getElementById']('pause-btn')['style']['display'] = 'block', _0x3b7a0d['rZIyA'](updateStatus, _0x3b7a0d['wukxx']);
    });
}
function checkProgress() {
    const _0x1ff47b = a0_0x3c9c40, _0xa5205b = {
            'pIuNO': function (_0x281c39, _0x358082, _0x2dce00) {
                return _0x281c39(_0x358082, _0x2dce00);
            },
            'oLHlM': 'Error: Could not connect to background process.',
            'habDw': function (_0x5026e3, _0x3c3898) {
                return _0x5026e3 === _0x3c3898;
            },
            'yKPfj': 'started',
            'iInqz': 'start-btn',
            'AgFav': 'none',
            'xAzOW': 'pause-btn',
            'COGEy': 'block',
            'FUUNO': function (_0x133e25, _0x40627c) {
                return _0x133e25(_0x40627c);
            },
            'GxLOO': 'Sending in progress... Please keep WhatsApp Web open.',
            'DNYMW': function (_0x440590, _0x460f97) {
                return _0x440590 + _0x460f97;
            },
            'BUVQY': 'Error: ',
            'IqNgP': 'file-upload',
            'ZDlCv': function (_0x1f48f7, _0x587571) {
                return _0x1f48f7 !== _0x587571;
            },
            'yfZUw': 'KWUBs',
            'oiEII': function (_0x5dbecd, _0x5a48af) {
                return _0x5dbecd(_0x5a48af);
            },
            'kOmdj': function (_0x141855, _0x572ede) {
                return _0x141855 > _0x572ede;
            },
            'Xcove': function (_0xbc26bf, _0x58609d) {
                return _0xbc26bf >= _0x58609d;
            },
            'cDpkX': function (_0x3b654d, _0x29db9b) {
                return _0x3b654d === _0x29db9b;
            },
            'YuWAk': 'riCvM',
            'BHoWZ': function (_0x5dbe1f, _0x22b664) {
                return _0x5dbe1f(_0x22b664);
            },
            'XroHi': 'Finished sending!',
            'Veqcx': 'action-buttons',
            'ncVxx': 'report-btn',
            'JbAei': function (_0x2e073b, _0x1c22a9) {
                return _0x2e073b(_0x1c22a9);
            }
        }, _0x3adf95 = setInterval(() => {
            const _0x3165ad = _0x1ff47b, _0x487b33 = {
                    'aNTEx': _0xa5205b['AgFav'],
                    'oBLnA': 'report-btn',
                    'hDQly': _0xa5205b['COGEy'],
                    'CNVka': function (_0x443a4a, _0x424b15) {
                        const _0x171970 = _0x3165ad;
                        return _0xa5205b['JbAei'](_0x443a4a, _0x424b15);
                    },
                    'gYNUE': _0xa5205b['XroHi']
                };
            chrome['runtime']['sendMessage']({ 'action': 'get_status' }, _0x2622e2 => {
                const _0x20156b = _0x3165ad, _0x42d285 = {
                        'uKyqL': function (_0x730954, _0x2e2ab2, _0xf3898f) {
                            return _0xa5205b['pIuNO'](_0x730954, _0x2e2ab2, _0xf3898f);
                        },
                        'LDwfS': _0xa5205b['oLHlM'],
                        'ttlRu': function (_0xa15d22, _0x27c89e) {
                            return _0xa5205b['habDw'](_0xa15d22, _0x27c89e);
                        },
                        'LKMuC': _0xa5205b['yKPfj'],
                        'CYYhB': _0xa5205b['iInqz'],
                        'csEot': _0xa5205b['AgFav'],
                        'zQxLJ': 'flex',
                        'TwzFF': _0xa5205b['xAzOW'],
                        'PyxCU': _0xa5205b['COGEy'],
                        'TnwtF': 'resume-btn',
                        'mZIWF': function (_0x47f41e, _0x39ebd9) {
                            const _0x453742 = _0x20156b;
                            return _0xa5205b['FUUNO'](_0x47f41e, _0x39ebd9);
                        },
                        'Niaqc': _0xa5205b['GxLOO'],
                        'qsPtC': function (_0x47eeb3, _0x4dc7f5) {
                            const _0x244b67 = _0x20156b;
                            return _0xa5205b['DNYMW'](_0x47eeb3, _0x4dc7f5);
                        },
                        'oMjgn': _0xa5205b['BUVQY'],
                        'AivaD': _0xa5205b['IqNgP']
                    };
                if (!_0x2622e2) {
                    _0xa5205b['FUUNO'](clearInterval, _0x3adf95);
                    return;
                }
                if (_0x2622e2['isSending'])
                    _0xa5205b['FUUNO'](updateStatus, 'Sending: ' + _0x2622e2['currentIndex'] + ' of ' + _0x2622e2['totalCount'] + ' completed.');
                else {
                    if (_0xa5205b['ZDlCv'](_0xa5205b['yfZUw'], _0xa5205b['yfZUw']))
                        _0x831002['getElementById']('start-btn')['style']['display'] = _0x487b33['aNTEx'], _0x186423['getElementById'](_0x487b33['oBLnA'])['style']['display'] = _0x487b33['hDQly'], _0x487b33['CNVka'](_0x28cc96, _0x487b33['gYNUE']);
                    else {
                        _0xa5205b['oiEII'](clearInterval, _0x3adf95);
                        if (_0xa5205b['kOmdj'](_0x2622e2['totalCount'], 0) && _0xa5205b['Xcove'](_0x2622e2['currentIndex'], _0x2622e2['totalCount'])) {
                            if (_0xa5205b['cDpkX']('ppfvA', _0xa5205b['YuWAk'])) {
                                if (_0x129bc4['runtime']['lastError']) {
                                    UqvIyO['uKyqL'](_0x402e9c, UqvIyO['LDwfS'], !![]), _0x5d547c['error'](_0x5613d1['runtime']['lastError']);
                                    return;
                                }
                                if (_0x40565f && UqvIyO['ttlRu'](_0x5287f9['status'], UqvIyO['LKMuC']))
                                    _0x55c2fb['getElementById'](UqvIyO['CYYhB'])['style']['display'] = UqvIyO['csEot'], _0x2d1feb['getElementById']('action-buttons')['style']['display'] = UqvIyO['zQxLJ'], _0x5c2b24['getElementById'](UqvIyO['TwzFF'])['style']['display'] = UqvIyO['PyxCU'], _0x1f059b['getElementById'](UqvIyO['TnwtF'])['style']['display'] = UqvIyO['csEot'], UqvIyO['mZIWF'](_0x55070b, UqvIyO['Niaqc']), _0x529268();
                                else
                                    _0x3388d5 && _0x94f7b['error'] && (_0x5e6476(UqvIyO['qsPtC'](UqvIyO['oMjgn'], _0x136953['error']), !![]), _0x2b2662['getElementById'](UqvIyO['CYYhB'])['disabled'] = ![], _0x3aa3f5['getElementById'](UqvIyO['AivaD'])['disabled'] = ![]);
                            } else
                                _0xa5205b['BHoWZ'](updateStatus, _0xa5205b['XroHi']), document['getElementById'](_0xa5205b['iInqz'])['style']['display'] = _0xa5205b['AgFav'], document['getElementById'](_0xa5205b['Veqcx'])['style']['display'] = _0xa5205b['AgFav'], document['getElementById'](_0xa5205b['ncVxx'])['style']['display'] = _0xa5205b['COGEy'];
                        }
                    }
                }
            });
        }, 1000);
}
function openReport() {
    const _0x53ab84 = a0_0x3c9c40, _0x19efbe = { 'FWXKp': 'report.html' };
    chrome['tabs']['create']({ 'url': chrome['runtime']['getURL'](_0x19efbe['FWXKp']) });
}
function a0_0x48a6() {
    const _0x2ee316 = [
        'q1LzAei',
        'zg93BMXVywqTC2fTCgXL',
        'wKTvBMu',
        'tNbbvvq',
        'zwD3y2i',
        't25AEui',
        'Eef6t1C',
        'qK9sDKO',
        'y29SB3i',
        'rfj1quu',
        'AxnqyxvZzwq',
        're5ztvC',
        'rwD1wwq',
        's0n3yvu',
        'Bw1oBNe',
        'vuPxChu',
        'DhjPBq',
        'wfHUzK8',
        'wKn2wwK',
        'zfnXyuG',
        'Eu1zEhq',
        'tvPmuNa',
        'rxLcvhm',
        'zuDSv2K',
        'ywn0AxzHDguTyNrU',
        'yNfPrgG',
        'ExjQD2S',
        's3jdr3K',
        'ywjSEgi',
        'BM9Uzq',
        'De5Lr3e',
        'vMLfC2G',
        'z3bQvvG',
        'wfjOyMC',
        'C2LSB0nHBxbHAwDUCW',
        'rxrSBvC',
        'Bw9IAwXL',
        'yxv0BW',
        'zw5KC1DPDgG',
        'C3rYAw5N',
        'EeXez0W',
        'reTXrNO',
        'AwXwEfm',
        'AgvPz2H0',
        'B2jZyMO',
        'suDOr28',
        'tMLHCwm',
        'BgfZDevYCM9Y',
        'qKHPCNq',
        'C3rHDhvZ',
        'z3DPDfu',
        'mZqZndm4ufzSqLbv',
        'mZu5odCYrLj2twfM',
        'Bhf3q0m',
        'tuPizKG',
        'vLHeDwW',
        'Aw5JBhvKzxm',
        's3v1ANC',
        'rxjYB3i6ia',
        't2XNwM8',
        'u2HLzxrZ',
        'sentrw0',
        'u2vUzgLUzYbPBIbWCM9NCMvZCY4UlIbqBgvHC2uGA2vLCcbxAgf0C0fWCcbxzwiGB3bLBI4',
        'DMfSDwu',
        'wuvmDei',
        'BKv6Dwu',
        'CgHVBMu',
        'y3nfB3q',
        'whD1vuq',
        'tLf2EuG',
        'uKHACxG',
        'A2jZuwK',
        'teX2Dum',
        'Cw5uDxi',
        'q09hrxK',
        'DgfICW',
        'yurPzfa',
        'BePKCKS',
        'zgvSyxKTBwf4',
        'CMvHzefZvgv4Da',
        'CMvWB3j0lMH0BwW',
        'mta5nKXhChrbsW',
        'CxnqDem',
        'DMnpDei',
        'wg9Oy1y',
        'zunwwLK',
        'zgvSyxKTBwLU',
        'BMnZtvm',
        'ig9Mia',
        'zLfYuw8',
        'BeHLwwm',
        's2PZAeC',
        'tvzeu2i',
        'mJi4nZbQq2vxBeC',
        'qwn0AxzHDgLVBIbMB3jJzwqGDg8GzxHWAxjLlG',
        'rxjYB3i6ienVDwXKig5VDcbJB25Uzwn0ihrVigjHy2TNCM91BMqGChjVy2vZCY4',
        'yxbWzw5Kq2HPBgq',
        'Buvvtxa',
        'D0rNrLC',
        'Bhrztw8',
        'DMfSAwrHDgvFywn0AxzHDgLVBL9RzxK',
        'wMH4vNm',
        'Ee9RExu',
        'sw52ywXPzcbHy3rPDMf0Aw9UigTLEs4',
        'sfbWAwC',
        'v1H4q00',
        'CMvWBgfJzq',
        'r3rmwgy',
        'BwLU',
        'rxjYB3iGCgfYC2LUzYbdu1yGzMLSzs4',
        'q3H1CwG',
        'u2XKz2C',
        'zM9UDfDLAwDODa',
        'tK9LsMO',
        'vNDPA1e',
        'ruTpAM8',
        'twL0ywe',
        'vufYy2S',
        'zgf0ytP0zxH0l2nZDJTJAgfYC2v0pxv0zI04lenoie51BwjLCIXdt0qGqw1VDw50lenVBNnPz25Lzsboyw1LlfbOB25Lie51BwjLCGOXmJm0nty3odKSmtuWmcXbBgKGs2HHBIW5mJmWmdeYmZq1nJCkotG3nJu0mZiXldi1mdaSvxnTyw4GqwXPldKYmZaWnZy1ndmYmq',
        'u2vUzgLUzYbYzxn1BwvKlI4UifbSzwfZzsbRzwvWifDOyxrZqxbWifDLyIbVCgvUlG',
        'AePru3u',
        'B25SB2fK',
        'mZu1ndfkyuvLEg4',
        'surQt1u',
        'sePdsLK',
        'q1bXBuS',
        'sKH3sxa',
        'C1jeEeS',
        'ywrKrxzLBNrmAxn0zw5LCG',
        'CxnTsMW',
        'rhbjsKy',
        'zhjHAw4TDgLTzs1IDg4',
        'vgjhC0W',
        'sMvkA0q',
        'zuDZv0m',
        'DNveExi',
        'EwzAvxC',
        'ter4DwO',
        'AxHUC2q',
        'u2HLzxroyw1LCW',
        'teTnDum',
        'BgnNv0S',
        'ChbMDKe',
        'y2jJAKO',
        'BurkDha',
        'BgrLBfG',
        'v1nmzvi',
        'wxvxqwS',
        'B3b0Aw9U',
        'tuf0AMK',
        'DhzAvuS',
        'ChfKBMq',
        'u3HKqxq',
        'zxLRthu',
        'ter3zLm',
        'yMXVy2S',
        'y3vYCMvUDeLUzgv4',
        'Aw9evvi',
        'BwfPBI1HChaTDMLLDW',
        'q05wA2e',
        'DxrPBhm',
        'EuTqzMO',
        'tNP3wuy',
        'whrnsfK',
        'z1Lovuu',
        'u053DwW',
        'Aw52ywXPza',
        'Bhz0qLC',
        'qwDgyxy',
        'shj1qKC',
        'q2Hxtw4',
        'ChjLDMvUDerLzMf1Bhq',
        'sNHzvxu',
        'zNHsz2W',
        'Ahv3v24',
        'BwvZC2fNzq',
        'z2v0vvjm',
        'CvL0tuW',
        'uMnNsMy',
        'uwnMAMK',
        'y29UC2LNBMvL',
        'DMzgyui',
        'z3H2A28',
        'tuHAEgm',
        'veD4sxi',
        'zxjYB3i',
        'C2vUze1LC3nHz2u',
        'y2XHC3noyw1L',
        'wKrmqvm',
        'nMP2zuTtBW',
        'zLz1B3q',
        'AMDTzha',
        'EgPqzhy',
        'C29Tzq',
        'AeHZCem',
        'DNbht0e',
        'Cg9PBNrLCG',
        'zMXVB3i',
        's3zutfC',
        'yvr6ugK',
        'wxDbAxe',
        'zgTpBeq',
        'vu1XEMe',
        'y2fTCgfPz24TC2vSzwn0',
        'wg1oq0m',
        'qKLyvgq',
        'wKzXAxq',
        'uxreyxm',
        'ywn0AxzHDgLVBI12Awv3',
        'q3neyKO',
        'nhWYFdb8m3WX',
        's0frtfu',
        'wM9NBLK',
        'twTqsxy',
        'zgLZywjSzwq',
        's3jUAu0',
        'B21nq3K',
        'sffID3K',
        'qw5PyKK',
        'C2HLzxrFDg9FANnVBG',
        'DKHuDhm',
        'Axnnyxn0zxi',
        'ywn0AxzHDgvK',
        'DgfYz2v0',
        'C3r5Bgu',
        'vwX5AvG',
        'wKrSq3y',
        'shLoDw4',
        'zwL2DuC',
        'tKLwDLi',
        'q2fUBM90ihnHDMuGyw4Gzw1WDhKGDgvTCgXHDguU',
        'BMrzBxG',
        'C2LSB1rLBxbSyxrL',
        'Duvvvgu',
        'vfzVAxC',
        'y3vZDg9Tzxi',
        'BuPPALC',
        'rKPjAuO',
        'Ae1QvLi',
        'svvMuu8',
        'shrfwwK',
        'ywn0AxzHDgLVBI1ZDgf0Dxm',
        'nuLbt3nXva',
        'u2DzCvC',
        'u2n6Dem',
        'ug5AEMu',
        'm3WYFdb8mxW0',
        'EKPPsMG',
        'BKPmAxe',
        'D0nyt28',
        'sMThDfy',
        'sLn2tgS',
        'BM9YBwfS',
        'u2vHv0C',
        'wNrHzNy',
        'u3vJy2vZC2z1BgX5igXVywrLzca',
        'EgrhqNG',
        'z2v0',
        'rurjv0C',
        'vLrwtLi',
        'yw1VDw50',
        'zerNAMm',
        'ywn0AxzHDgLVBI1RzxK',
        'CMvZDwX0',
        'uw5dAwC',
        'r3nruuq',
        'z2v0x3n0yxr1CW',
        'y29K',
        'rMLUAxnOzwqGC2vUzgLUzYe',
        'sxfoz1a',
        'v3bIt2i',
        'C2nYB2XSsgvPz2H0',
        'B3nTtgm',
        'C2LesKO',
        'C3rHCNqTyNrU',
        'yM9KEq',
        'ChvZAa',
        'Dg9gD1e',
        'lMnZDG',
        'swzKEKy',
        'y29UC2LNBM1LBNq',
        'Bwf4',
        'u0DLC24',
        'txvuAvO',
        'qvb3ze0',
        'vuzyqLa',
        'B3LKz1G',
        'B2LfsuK',
        'ignVBxbSzxrLzc4',
        'y291BNrKB3DUlwzVB3rLCG',
        'CfPstwy',
        'zLDHrvm',
        't2nVv3i',
        'swjdq00',
        'DMH6ENe',
        'zMLUzeLUzgv4',
        'u0LPy00',
        'C3rHCNrFC2vUzgLUzW',
        'sM5zvwC',
        'sMjfyM8',
        'zuPnrhK',
        'C3LsEKi',
        'tM8GzMLSzsbZzwXLy3rLza',
        'CgfKu3rHCNq',
        'y2HHBMDL',
        'zMXLEa',
        'vhnnAKW',
        'r05JzeS',
        'A3bduxm',
        'DMz0vNm',
        'uMrgte8',
        'rK9YDLy',
        'tNnpyvy',
        'y0Tsvhu',
        'zMLSzs11CgXVywq',
        'wxvcuhm',
        's1nvqwK',
        'rwnJzxy',
        'AuviDgC',
        'yM5MvK0',
        'CNvUDgLTzq',
        'u0P2uhC',
        'sMjbzwK',
        'vLfKAe4',
        'ru1Mzui',
        'tLHIq3C',
        'qwL2yuq',
        'wgnVDMu',
        'CxPfDhi',
        'AuLUCxO',
        'C0fTt0O',
        'BMfTzq',
        'AwLsvLC',
        'DuzzvgW',
        'z1ffDeO',
        'CLPjEue',
        'vNn5tgC',
        'mtKYnvLsv3LUyW',
        'vg53Dey',
        'y2HLy2TFywn0AxzHDgLVBL9ZDgf0Dxm',
        'CMTgrKe',
        'ANHKz2u',
        'CxzvEMy',
        'zLPPv1q',
        'Cerws0q',
        'vevAwhC',
        'z0PPCeO',
        'qvrAwvK',
        'Cvr5sK8',
        'uMHRyMe',
        'wvnWDw8',
        'BwfW',
        'wff1z3e',
        'tvr6t2S',
        'yu5urxG',
        'tfLLDKW',
        'DuThveq',
        'DxHZsKG',
        'A1rmtK4',
        'vffbt2K',
        't2vIAeC',
        'rLvvtK8',
        'zxvSys1JAgvJA2jVEa',
        'AgfOCgq',
        'wxLMqM0',
        'r3Hmt08',
        'DvHJwuS',
        'DKDluhC',
        'BKjXuKu',
        'Dg90ywXdB3vUDa',
        'C2v0',
        'uxfXsNO',
        'pg9WDgLVBIb2ywX1zt0IzgvMyxvSDci+ls0Gu2vSzwn0igeGq2fTCgfPz24GvgvTCgXHDguGls08l29WDgLVBJ4',
        'EeTzC0u',
        'u3rHCNrPBMCUlI4',
        'y01UDK0',
        'C3jouvG',
        'y2jWAxa',
        'sufLq2i',
        'Cgf1C2uTyNrU',
        'CMLdDK0',
        'B1fkBvu',
        'C2v0qxr0CMLIDxrL',
        'ChjLDMLLDY1JB250ywLUzxi',
        'ohW0Fdf8n3W5Fdj8nNWWFdv8mW',
        'CMfxCLi',
        'rhn1wvO',
        'DfjUt1q',
        'wNHwsg4',
        'wMLZDum',
        'mty2mdq0oxvbD1rpAa',
        'CMvZDw1Llwj0BG',
        'CKDnque',
        'zMLSzxm',
        'zg93BMXVywq',
        'B0XiBe0',
        'q0PHsNe',
        'Aw5WDxq',
        'sgHrB0K',
        'Aw5Uzxjive1m',
        'CuPdrKO',
        'y2HLy2TLza',
        'ANnjt2m',
        'rhLuDuS',
        'D0jeAxy',
        'rLf2sfO',
        'ugXLyxnLigvUDgvYigeGA2v5lG',
        'z2v0rwXLBwvUDej5swq',
        'vgDozgK',
        'mc41',
        'v2DMr2e',
        'CMvHza',
        'mtyZnZaZodHKAKHuy3u',
        'C3bSAxq',
        'u09Zteu',
        'y1Dcr1a',
        'A09TzgO',
        'ywn0Aw9Ulwj1DhrVBNm',
        'B0jmBKe',
        'wef1tKu',
        'EuTrC00',
        'wKrSBem',
        'qLvwuvK',
        'whjVsgK',
        'ntu5mZCYtMPrrMn2',
        'AfnRDhu',
        'z1zSzfu',
        'CuPYCgm',
        'A0DvDxu',
        'EvDwuwG',
        'BNDVsee',
        'm3jICuDqqW',
        'DMDLzge',
        'BgvUz3rO',
        'rLDys3a',
        'wfHVs2W',
        'r0zVu28',
        'y3jLyxrL',
        'i2vMndq0na',
        'CMvHzefZqMLUyxj5u3rYAw5N',
        'yNbZs3q',
        'C2f2zs1Jyw1WywLNBI1IDg4',
        'DuT5CuW',
        'yvvrs3C',
        'DhrSuNu',
        'BK1wruO',
        'BvPjv0y',
        'DhbSwgi',
        'u2vUzgLUzYbWyxvZzwqU',
        'u2vUzgLUzYbZDg9WCgvKigfUzcbYzxnLDc4',
        'qK1ywwC',
        'vMvXy3G',
        'qwn0AxzHDgLVBIbZDwnJzxnZzNvSiq',
        'zKTxCge',
        'q1n1DMe',
        'sLnKyMm',
        'zwLrtMu',
        'mxW1Fdr8mNWWFdm',
        'rLLIwNK',
        'rxjYB3iGCgfYC2LUzYbMAwXLlIbqBgvHC2uGzw5ZDxjLigL0j3mGysb2ywXPzcbdu1yVrxHJzwWGzMLSzs4',
        'tM8GDMfSAwqGzgf0ysbMB3vUzc4Grw5ZDxjLihLVDxiGzMLSzsbOyxmGugHVBMuGtNvTyMvYCY4',
        'C3rHCNrLza',
        'Dgv4DenVBNrLBNq',
        'u21oAvO',
        'vg90ywWGDMfSAwqGCM93CZOG',
        'AhjLzG',
        'zvDptu8',
        'z1jpy3a',
        'Cfb4rxm',
        'D3vREhG',
        'zvbMEui',
        'y3vYC29Y',
        'vMvYAwz5Aw5NlI4U',
        'vfjnyxO',
        'vMn4swy',
        'yMLUyxj5',
        're9nq29UDgvUDeXVywrLza',
        'wezoEMO',
        'wgHPDw0',
        'C2LSB19Zyw1WBguUy3n2',
        'sxfRv1K',
        'qwn0AxzHDgLVBIbLEhbPCMvKlG',
        'yMz1Eve',
        'B3bHy2L0Eq',
        'vMvYAwzPy2f0Aw9UigzHAwXLzc4Gq2HLy2SGEw91CIbJB25Uzwn0Aw9UlG',
        'z3DpDw0',
        'CMvTywLUAw5NvgLTzq',
        'DMfYkc0TDgv4Dc1JB2XVCIK',
        'BM90lwfSBg93zwq',
        'ChjLDMLLDY1IB2r5',
        'AKT4D3e',
        'D2T2uMq',
        'r2DlA1y',
        'twvXzuq',
        'CMvZDw1Lx3nLBMrPBMC',
        'zgLZCgXHEq',
        'v1vUs3O',
        'vxjWve8',
        'D3PQtw8',
        'v3L0Afm',
        'DhjHy2TPBMC',
        'uLDMAKW',
        'C3vJy2vZCW',
        'u2vUzgLUzZOG',
        'y0rJqLq',
        'CMvTB3zLq2HPBgq',
        'zLbdz1e',
        'CMvWB3j0lwj0BG',
        'rNHMCxG',
        'ANHZEve',
        'zw9crw0',
        't3r6qNK',
        'sMz2DKy',
        'DK5Xr0S',
        'DMfYkc0TAw5MBY1JB2XVCIK',
        'wM1Ot3O',
        'nJaW',
        'Axntzw5KAw5N',
        'wNDKCvu',
        'vvHetey',
        'qKHVv1O',
        'AfrTtNa',
        'twz1tw4',
        'vNfKuNa',
        'sKfusM0',
        'vxvxvhm',
        'sNDWwLK',
        'y3jLyxrLrwXLBwvUDa',
        'A2LgAe4',
        'Bhz3wgW',
        'CeHWEKG',
        'y2XPy2S',
        'AerrBhK',
        'Bg9JywW',
        'C1r3u3e',
        'ihjLy29YzhmU',
        'ufjmr0K',
        'Ce15s2K',
        'm3WXFdb8nxWYFdq',
        'wK9vAw4',
        'C3rVCMfNzq',
        'zejXzNq',
        'DgvTCgXHDguTAw5WDxq',
        'BwrAA3y',
        'rNjTtfy',
        'EwfKyLy',
        'ChjLDMLLDY1JB3vUDa',
        'q3LbAwe',
        'y29UDgfJDa'
    ];
    a0_0x48a6 = function () {
        return _0x2ee316;
    };
    return a0_0x48a6();
}
document['addEventListener']('DOMContentLoaded', () => {
    const _0xed80f9 = a0_0x3c9c40, _0x31562a = {
            'OMhMO': function (_0x344945, _0x153a8e) {
                return _0x344945 !== _0x153a8e;
            },
            'lvtBW': 'none',
            'Kuujw': 'file-name-display',
            'dDgjc': 'var(--text-color)',
            'qnTur': 'splash-screen',
            'bpsKt': function (_0x1ad07e, _0x59ef40) {
                return _0x1ad07e !== _0x59ef40;
            },
            'YELtB': 'tvZUK',
            'QFwXs': function (_0x304411, _0x5ef2f6, _0x4963a3) {
                return _0x304411(_0x5ef2f6, _0x4963a3);
            },
            'Mitaa': 'start-btn',
            'HhQoI': 'action-buttons',
            'mEUMp': 'flex',
            'kbsQi': 'pause-btn',
            'YSpuo': 'resume-btn',
            'qzEtr': 'block',
            'pHpzH': 'Sending paused.',
            'eJMDy': 'file-upload',
            'txFTb': 'preview-container',
            'WXxCM': function (_0x44e8b5) {
                return _0x44e8b5();
            },
            'NXbCw': function (_0x4bb291, _0x3947b2) {
                return _0x4bb291(_0x3947b2);
            },
            'TEZXw': 'No valid data found. Ensure your file has Phone Numbers.',
            'OsJfg': 'qYtML',
            'cOGAU': function (_0x138092, _0x43596b) {
                return _0x138092 === _0x43596b;
            },
            'hMjVR': 'QnCig',
            'XtMHY': 'ZmhOz',
            'eGsWC': 'kGUuu',
            'nEzue': function (_0x3b5687, _0x165653) {
                return _0x3b5687 > _0x165653;
            },
            'ZEeqC': function (_0x2247be, _0xac8b21) {
                return _0x2247be === _0xac8b21;
            },
            'NTsNl': 'qbAlm',
            'ZDLAS': 'report-btn',
            'BlxlJ': 'Finished sending!',
            'wkvRd': 'get_status'
        };
    setTimeout(() => {
        const _0x26da2b = _0xed80f9, _0x9c0dc6 = {
                'JkGtV': 'report.html',
                'omMCy': function (_0x2a5adb, _0x5cef23) {
                    return _0x31562a['OMhMO'](_0x2a5adb, _0x5cef23);
                },
                'UuWTs': 'UrpTO',
                'UArck': _0x31562a['lvtBW'],
                'WgfGa': _0x31562a['Kuujw'],
                'uXcYK': _0x31562a['dDgjc'],
                'wCXOo': '600',
                'MFyea': 'var(--info-color)',
                'HtEYi': 'normal'
            }, _0x17fbdc = document['getElementById'](_0x31562a['qnTur']);
        if (_0x17fbdc) {
            if (_0x31562a['bpsKt']('XRhbg', _0x31562a['YELtB']))
                _0x17fbdc['style']['opacity'] = '0', _0x31562a['QFwXs'](setTimeout, () => {
                    const _0x25b33a = _0x26da2b;
                    _0x9c0dc6['omMCy']('UrpTO', _0x9c0dc6['UuWTs']) ? _0x56304d['tabs']['create']({ 'url': _0x4eeb49['runtime']['getURL'](dGhkxI['JkGtV']) }) : _0x17fbdc['style']['display'] = _0x9c0dc6['UArck'];
                }, 500);
            else {
                const _0x38f1ca = _0x1fe860['getElementById'](dGhkxI['WgfGa']);
                _0x342bd9 ? (_0x38f1ca['textContent'] = _0x29456b['name'], _0x38f1ca['style']['color'] = dGhkxI['uXcYK'], _0x38f1ca['style']['fontWeight'] = dGhkxI['wCXOo']) : (_0x38f1ca['textContent'] = 'No file selected', _0x38f1ca['style']['color'] = dGhkxI['MFyea'], _0x38f1ca['style']['fontWeight'] = dGhkxI['HtEYi']);
            }
        }
    }, 1500), _0x31562a['WXxCM'](checkActivation), _0x31562a['WXxCM'](loadCampaigns), chrome['storage']['local']['get'](['siloTemplate'], _0x7486cb => {
        const _0x4ac4c3 = _0xed80f9;
        _0x7486cb['siloTemplate'] ? (templateInput['value'] = _0x7486cb['siloTemplate'], _0x31562a['QFwXs'](setTimeout, autoResizeTextarea, 0)) : (templateInput['value'] = '', chrome['storage']['local']['set']({ 'siloTemplate': '' }));
    }), chrome['runtime']['sendMessage']({ 'action': _0x31562a['wkvRd'] }, _0x2a60bd => {
        const _0x1f83ad = _0xed80f9, _0x3065a4 = {
                'UXDLF': function (_0x11b533, _0x13a626) {
                    const _0x356d08 = a0_0x1f3f;
                    return _0x31562a['NXbCw'](_0x11b533, _0x13a626);
                },
                'QtDas': function (_0x2be9e8, _0x53b03d, _0x293e57) {
                    return _0x2be9e8(_0x53b03d, _0x293e57);
                },
                'iEHtg': _0x31562a['TEZXw'],
                'gJipJ': _0x31562a['Mitaa'],
                'teRsb': 'none'
            };
        if ('UByLB' !== _0x31562a['OsJfg']) {
            if (_0x2a60bd && _0x2a60bd['isSending']) {
                if (_0x31562a['cOGAU'](_0x31562a['hMjVR'], _0x31562a['hMjVR']))
                    document['getElementById'](_0x31562a['Mitaa'])['style']['display'] = 'none', document['getElementById']('action-buttons')['style']['display'] = _0x31562a['mEUMp'], _0x2a60bd['isPaused'] ? _0x31562a['XtMHY'] === _0x31562a['eGsWC'] ? (_0x1ecc2d['textContent'] = _0x5b2e96['message'] || 'Verification failed. Check your connection.', _0x374d47['className'] = 'error') : (document['getElementById'](_0x31562a['kbsQi'])['style']['display'] = 'none', document['getElementById'](_0x31562a['YSpuo'])['style']['display'] = _0x31562a['qzEtr'], _0x31562a['NXbCw'](updateStatus, 'Sending paused.')) : (document['getElementById'](_0x31562a['kbsQi'])['style']['display'] = _0x31562a['qzEtr'], document['getElementById'](_0x31562a['YSpuo'])['style']['display'] = _0x31562a['lvtBW']), document['getElementById']('file-upload')['disabled'] = !![], document['getElementById'](_0x31562a['txFTb'])['style']['display'] = _0x31562a['lvtBW'], _0x31562a['WXxCM'](checkProgress);
                else {
                    kwVFDx['UXDLF'](_0x236aaf, _0xb297c7);
                    return;
                }
            } else {
                if (_0x2a60bd && _0x31562a['nEzue'](_0x2a60bd['totalCount'], 0) && !_0x2a60bd['isSending'] && _0x2a60bd['currentIndex'] >= _0x2a60bd['totalCount']) {
                    if (_0x31562a['ZEeqC']('vlArc', _0x31562a['NTsNl'])) {
                        kwVFDx['QtDas'](_0x248e97, kwVFDx['iEHtg'], !![]), _0x36d444['getElementById'](kwVFDx['gJipJ'])['disabled'] = !![], _0xff1846['getElementById']('preview-container')['style']['display'] = kwVFDx['teRsb'];
                        return;
                    } else
                        document['getElementById'](_0x31562a['Mitaa'])['style']['display'] = _0x31562a['lvtBW'], document['getElementById'](_0x31562a['ZDLAS'])['style']['display'] = _0x31562a['qzEtr'], _0x31562a['NXbCw'](updateStatus, _0x31562a['BlxlJ']);
                }
            }
        } else
            _0x58a689['getElementById'](_0x31562a['Mitaa'])['style']['display'] = _0x31562a['lvtBW'], _0x153022['getElementById'](_0x31562a['HhQoI'])['style']['display'] = _0x31562a['mEUMp'], _0x366775['isPaused'] ? (_0xceaa6c['getElementById'](_0x31562a['kbsQi'])['style']['display'] = _0x31562a['lvtBW'], _0x146ad2['getElementById'](_0x31562a['YSpuo'])['style']['display'] = _0x31562a['qzEtr'], _0x40c977(_0x31562a['pHpzH'])) : (_0x17ff62['getElementById'](_0x31562a['kbsQi'])['style']['display'] = _0x31562a['qzEtr'], _0xd18a7d['getElementById'](_0x31562a['YSpuo'])['style']['display'] = _0x31562a['lvtBW']), _0x4428a6['getElementById'](_0x31562a['eJMDy'])['disabled'] = !![], _0x3269c1['getElementById'](_0x31562a['txFTb'])['style']['display'] = _0x31562a['lvtBW'], _0x31562a['WXxCM'](_0x404fcc);
    });
});