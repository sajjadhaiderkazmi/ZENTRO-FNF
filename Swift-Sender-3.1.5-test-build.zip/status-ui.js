let swiftProgressTimer;
function checkProgress(){
 clearInterval(swiftProgressTimer);
 const refresh=()=>chrome.runtime.sendMessage({action:'get_status'},s=>{
  if(chrome.runtime.lastError||!s){updateStatus('Cannot reach the extension worker. Reload the extension and refresh WhatsApp.',true);clearInterval(swiftProgressTimer);return;}
  if(s.error){updateStatus(s.error,true);return;}
  const show=(id,on)=>document.getElementById(id).style.display=on?'block':'none';
  if(s.isSending){
   show('action-buttons',true);show('start-btn',false);show('pause-btn',!s.isPaused);show('resume-btn',s.isPaused);
   updateStatus(s.isPaused?'Paused: '+(s.reason||'Paused by you'):`${s.stage||'Sending'} — ${s.currentIndex} of ${s.totalCount} processed.`,s.isPaused&&!!s.reason);
  }else{
   clearInterval(swiftProgressTimer);show('action-buttons',false);show('start-btn',true);
   document.getElementById('file-upload').disabled=false;
   document.getElementById('start-btn').disabled=!parsedData.some(r=>!r.importError);
   if(s.totalCount)updateStatus(`${s.campaignStatus||'Stopped'}: ${s.currentIndex} of ${s.totalCount} processed. Check the report for sent and unknown outcomes.`);
  }
 });
 refresh();swiftProgressTimer=setInterval(refresh,1000);
}
