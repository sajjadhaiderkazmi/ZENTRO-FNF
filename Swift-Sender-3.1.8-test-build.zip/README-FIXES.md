# Swift Sender 3.1.8 — diagnostic test build

Extract this folder and load it through Chrome Extensions > Developer mode > Load unpacked. For an existing unpacked installation, back up its folder and replace its files in the same folder, then click Reload. This preserves the extension identity and its browser storage. Installing from another folder can create another extension identity; existing activation and records will not transfer automatically. Refresh WhatsApp Web once after updating to replace the old content script. Disable any other copy of Swift Sender.

Changes:
- No per-recipient tab navigation or page refresh. Uses New chat and searches the phone number inside WhatsApp.
- Each campaign and source row is saved before processing; stopping retains records. Worker restarts retain the current attempt. Uncertain attempts time out to Unknown and pause; they are never automatically resent.
- Success requires a new outgoing message with matching text and a WhatsApp checkmark. This is not proof the recipient read it.
- CSV imports preserve text numbers, first data rows and short rows. Supported headers include Phone, Mobile, Contact Number and WhatsApp Number. Headerless input supports one phone column or the original CN, COD, Name, Phone layout. Invalid rows remain visible in reports. No country code is guessed.
- Reports include every row with status and reason and export all campaigns to CSV. Legacy reports remain viewable; their historical inaccuracies cannot be reconstructed.

Use full international numbers, for example +923001234567. Local numbers such as 03001234567 are flagged for correction. Spreadsheet numbers already rounded by Excel cannot be recovered; format the source column as Text before exporting. Duplicate source rows are preserved and can therefore send twice; review the input first.

Live-test limitations:
- Automated regression tests passed; no messages were sent to real WhatsApp recipients during development.
- This build currently expects the English WhatsApp Web interface. A unique saved-name search result can now be opened. Its phone must match in the conversation header or Contact info before composing. Ambiguous search results and unverified numbers pause as Unknown.
- Interface changes may require selector adjustments. Unknown does not mean the number lacks a WhatsApp account. Check the recorded reason and chat manually before retrying.
- Pause prevents subsequent click authorization; a click already authorized may finish. Stop preserves such an outcome as Unknown if confirmation has not arrived.
- Activation behavior is retained. The legacy time-service domain is now declared in host permissions.
- Records live in Chrome local extension storage, not in a cloud backup. Export periodically. Uninstalling or clearing extension data removes them. Existing credentials and old reports are not migrated into a different extension identity.

Try two or three consenting test contacts first and compare the CSV rows with the report before using a larger list. Keep the WhatsApp tab open and avoid editing its chat while a campaign runs.

3.1.1 fixes a popup script loading-order error that left only the logo visible. Startup verified with both active and inactive activation states in a DOM harness. Live WhatsApp sending still requires user testing.

3.1.2 reads raw Excel cell values instead of scientific display strings. Full stored integer digits are preserved. Already-rounded source numbers cannot be recovered. Imported rows and filename are cached while the popup is open and for at least 45 seconds after closing (50-second expiry refreshed every 5 seconds). Reopening before expiry restores the preview and extends retention. This is the imported data, not access to the original local file. Expiry affects only this temporary preview; campaign records remain saved.

3.1.3 recognizes Consignee Phone and Customer Phone headers and displays rejection reasons beside each invalid phone. Version 3.1.3 rejected scientific text; version 3.1.4 now expands it as requested. Obtain the original full numbers and export the column as Text. Merely reformatting an already-rounded CSV cannot restore lost digits.

3.1.4 expands scientific notation with decimal-string arithmetic before queueing: 3.24E+09 becomes 3240000000. Preview and queue use full digits; reports retain the original value as well. This does not recover rounded digits or infer a country code. Repeated identical source values remain identical recipients. Converted rows show a warning. The ZIP now contains manifest.json directly at its root: select the extracted folder when using Load unpacked. Re-import the source file after updating to replace any old cached preview.

3.1.5 checks and reconnects the WhatsApp content script before starting, activates the selected WhatsApp tab without reloading, rejects stale messaging protocols, and shows current steps and pause reasons. Update in the same extension folder, reload the extension, then refresh WhatsApp once. Stop any old campaign before starting a new test. Tests cover reconnection failures, paused reasons and a simulated DOM send/checkmark flow; real WhatsApp selectors remain unverified. Test with one correct international phone number you control, not the rounded sample CSV.

3.1.6 supports focused New chat editable search fields without aria labels, input/search elements, and an already-open New chat panel. Input is selected within the target editor, and the entered phone is verified before searching for results. Five simulated search/send cases pass; live WhatsApp remains user-tested. Reload the extension, refresh WhatsApp once, stop the prior campaign, and import one correct international test number to verify.

3.1.7 adds the built-in talha template with the requested exact wording, without replacing an existing saved template named talha. A single saved-name result is selected and Contact info is used to verify the actual number. Pakistani mobile forms 03xxxxxxxxx and 3xxxxxxxxx are compared with +923xxxxxxxxx; full source digits are still required. Seven simulated send cases include matching and mismatched saved contacts; 14 queue/import tests pass. This does not constitute verification against a live WhatsApp account. Reload the extension and refresh WhatsApp once after replacing files. Stop an old campaign before testing a new one.

3.1.8 adds a user-triggered Download troubleshooting report button at the bottom of the popup. It reads structural DOM metadata and campaign/bridge state without entering text, opening chats or sending messages. Report generation does not pause an already-running campaign; pause/stop it first if required. Download the JSON while WhatsApp is in the stuck state and attach it in the support conversation. No new sending fix is claimed in this diagnostic release. The talha template remains included.
