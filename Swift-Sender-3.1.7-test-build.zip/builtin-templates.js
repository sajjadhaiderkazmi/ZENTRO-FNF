const SWIFT_TALHA_TEMPLATE = `Assalam-o-Alaikum {Consignee Name},

Aap ka parcel Leopard Courier office KAMOKE  aa chuka hai. 📦
📌 Tracking ID: {CN Number}
💵 COD Amount: Rs. {COD Amount}

Kindly reply in [OK]

🕒 Time: Meherbani karke shaam 5:00 baje se pehle office se apna parcel receive kar lein.

Shukriya!
Leopard Courier Service Near Girls Graduate College KAMOKE

OFFICE TIMING [10am to 5PM]`;
document.addEventListener('DOMContentLoaded',()=>{
 chrome.storage.local.get(['siloCampaigns'],data=>{
  const campaigns=data.siloCampaigns||{};
  if(Object.prototype.hasOwnProperty.call(campaigns,'talha'))return;
  campaigns.talha=SWIFT_TALHA_TEMPLATE;
  chrome.storage.local.set({siloCampaigns:campaigns},()=>loadCampaigns());
 });
});
