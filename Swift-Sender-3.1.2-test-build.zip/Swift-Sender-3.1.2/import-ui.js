let swiftDraftFileName = '';
async function handleFile(event) {
 const file=event.target.files[0];updateFileNameDisplay(file);if(!file)return;
 swiftDraftFileName=file.name;
 try {
  const csv=/\.csv$/i.test(file.name);
  const book=XLSX.read(csv?await file.text():await file.arrayBuffer(),{type:csv?'string':'array',raw:true,cellText:true});
  const rows=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1,raw:true,defval:'',blankrows:true});
  processData(rows);
 }catch(error){parsedData=[];document.getElementById('start-btn').disabled=true;updateStatus('Import failed: '+error.message,true);}
}
function processData(rows) {
 parsedData=SwiftImport.rows(rows,templateInput.value);
 renderPreview();const invalid=parsedData.filter(r=>r.importError).length;
 document.getElementById('start-btn').disabled=!parsedData.some(r=>!r.importError);
 document.getElementById('preview-count').textContent=`${parsedData.length} source rows; ${invalid} need correction (retained in reports).`;
 updateStatus(`Imported ${parsedData.length} rows. ${invalid} invalid rows will be recorded, not sent. Use country codes.`,invalid>0);
 saveSwiftDraft();
}

// Refresh while open; 50s TTL with a 5s heartbeat retains at least 45s after closing.
function saveSwiftDraft() {
 if (!parsedData.length) return;
 chrome.storage.local.set({swiftImportDraft:{version:2,rows:parsedData,fileName:swiftDraftFileName,expiresAt:Date.now()+50000}});
}
document.addEventListener('DOMContentLoaded',()=>{
 chrome.storage.local.get(['swiftImportDraft'],data=>{
  const draft=data.swiftImportDraft;
  if(!draft||draft.version!==2||!Array.isArray(draft.rows)||draft.expiresAt<=Date.now())return;
  // Do not overwrite a newly selected file while storage is loading.
  if(parsedData.length||swiftDraftFileName)return;
  parsedData=draft.rows;swiftDraftFileName=draft.fileName||'Imported contacts';
  renderPreview();updateFileNameDisplay({name:swiftDraftFileName});
  const invalid=parsedData.filter(r=>r.importError).length;
  document.getElementById('start-btn').disabled=!parsedData.some(r=>!r.importError);
  document.getElementById('preview-count').textContent=`${parsedData.length} restored source rows; ${invalid} need correction.`;
  updateStatus(`Restored ${parsedData.length} rows from ${swiftDraftFileName}.`);
  saveSwiftDraft();
 });
 setInterval(saveSwiftDraft,5000);
});
window.addEventListener('pagehide',saveSwiftDraft);
